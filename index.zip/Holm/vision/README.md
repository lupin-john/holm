# vision/

v1에서는 아직 구현되지 않았습니다.
UI/인터페이스 자리(placeholder)는 `public/js/tools-vision.js`에 있습니다.

**v5 계획:** 이미지 업로드 → 백엔드 전달 → Vision API(OCR/사진 분석) 호출 →
결과를 AI Brain에 전달하는 파이프라인을 이 폴더에 구현합니다.
