"""
server.py

v1에서는 실행하지 않아도 됩니다 (프론트엔드만으로 데모가 동작함).
v2에서 실제 AI API를 연결할 때 사용할 최소 Flask 백엔드 스켈레톤입니다.

핵심 원칙:
- API KEY는 .env에서만 읽고, 절대 프론트엔드로 내려주지 않는다.
- 프론트엔드(public/js/model-adapter.js)의 BackendAdapter가
  이 서버의 /api/chat 엔드포인트를 호출하도록 설계되어 있다.

실행 방법 (v2부터):
  1) pip install -r requirements.txt
  2) .env.example을 .env로 복사하고 API KEY 입력
  3) python server.py
"""

import os
from flask import Flask, request, jsonify

# from dotenv import load_dotenv
# load_dotenv()

app = Flask(__name__, static_folder="../public", static_url_path="")

# 실제 사용 시 .env에서 읽어온다. (예: os.environ.get("ANTHROPIC_API_KEY"))
API_KEY = os.environ.get("AI_API_KEY", None)


@app.route("/")
def index():
    return app.send_static_file("index.html")


@app.route("/api/chat", methods=["POST"])
def chat():
    """
    요청 형식 (public/js/model-adapter.js의 BackendAdapter가 보내는 형태):
    {
      "system": "...",
      "history": [...],
      "userInput": "..."
    }
    """
    body = request.get_json(force=True) or {}
    user_input = body.get("userInput", "")

    if not API_KEY:
        # v1/v2 초기: 실제 API 키가 없을 때의 안전한 fallback 응답
        return jsonify({
            "reply": f'(서버에 API KEY가 설정되지 않았어요) "{user_input}"을(를) 받았어요.'
        })

    # TODO(v2): 여기서 실제 AI API(OpenAI/Anthropic/Google 등)를 호출한다.
    # 예:
    # response = call_ai_api(API_KEY, body["system"], body["history"], user_input)
    # return jsonify({"reply": response})

    return jsonify({"reply": "AI API 연동은 다음 단계에서 구현됩니다."})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
