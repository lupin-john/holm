# tools/

v1의 실제 Tool 구현은 `public/js/tools-*.js`에 있습니다.

- `tools-calculator.js` — 계산기 (구현됨)
- `tools-time.js` — 현재 시각 (구현됨)
- `tools-date.js` — 오늘 날짜 (구현됨)
- `tools-search.js` — 웹 검색 (v4에서 실제 연결 예정, 지금은 placeholder)
- `tools-files.js` — 파일 정보 표시 (구현됨, 텍스트 추출은 v6 예정)
- `tools-vision.js` — 이미지 분석 (v5에서 구현 예정, 지금은 placeholder)

각 Tool은 `{ name, description, execute() }` 형태의 공통 인터페이스를 따릅니다.
새 Tool을 추가할 때도 이 형태를 유지하면 `brain.js`에서 쉽게 라우팅할 수 있습니다.
