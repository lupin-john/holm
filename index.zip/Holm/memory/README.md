# memory/

v3부터 실제 구현은 다음 파일들에 있습니다.

- `public/js/db.js` — IndexedDB 공용 래퍼
- `public/js/memory-db.js` — Memory 시스템 (타입/중요도/신뢰도/중복 방지)
- `public/js/knowledge-db.js` — Knowledge DB (별도 지식 저장소)
- `public/js/reflection.js` — Reflection Engine (대화에서 기억 후보 추출)
- `public/js/retrieval.js` — Context Retrieval (관련 기억/지식만 검색)
- `public/js/conversation-log.js` — 대화 로그 + LoRA 학습용 JSONL 준비
- `public/js/export-import.js` — JSON Export/Import
- `public/js/memory-ui.js` — 기억 관리 UI

`public/js/memory.js`(v1/v2 방식)는 더 이상 사용되지 않고 호환을 위해서만 남아있습니다.
