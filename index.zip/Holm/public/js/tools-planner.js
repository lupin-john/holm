/**
 * tools-planner.js
 * 채팅에서 자연어 명령으로 Planner를 조작하는 Tool 레이어.
 *
 * 지원 명령 예:
 *   "할일 추가: 수학 숙제하기"
 *   "할일 목록"
 *   "할일 완료: 2"
 *   "할일 삭제: 1"
 */

const PlannerTool = {
  name: "planner",
  description:
    "할 일을 관리합니다. 예: '할일 추가: 숙제하기', '할일 목록', '할일 완료: 2', '할일 삭제: 1'",

  tryHandle(text) {
    const addMatch = text.match(/^할\s*일\s*추가\s*[:：]?\s*(.+)$/);
    if (addMatch) {
      HolmPlanner.addTask(addMatch[1].trim());
      return `할 일을 추가했어요: "${addMatch[1].trim()}"`;
    }

    if (/^할\s*일\s*목록/.test(text)) {
      return this.formatList();
    }

    const doneMatch = text.match(/^할\s*일\s*완료\s*[:：]?\s*(\d+)$/);
    if (doneMatch) {
      const task = HolmPlanner.completeByIndex(parseInt(doneMatch[1], 10));
      return task ? `완료 처리했어요: "${task.text}"` : "그 번호의 할 일을 찾을 수 없어요.";
    }

    const delMatch = text.match(/^할\s*일\s*삭제\s*[:：]?\s*(\d+)$/);
    if (delMatch) {
      const task = HolmPlanner.removeByIndex(parseInt(delMatch[1], 10));
      return task ? `삭제했어요: "${task.text}"` : "그 번호의 할 일을 찾을 수 없어요.";
    }

    if (/^할\s*일\s*(전체\s*)?(삭제|초기화)$/.test(text)) {
      HolmPlanner.clearAll();
      return "할 일 목록을 모두 초기화했어요.";
    }

    return null;
  },

  formatList() {
    const tasks = HolmPlanner.getAll();
    if (!tasks.length) return "아직 등록된 할 일이 없어요.";
    return tasks
      .map((t, i) => `${i + 1}. ${t.done ? "✅" : "⬜"} ${t.text}`)
      .join("\n");
  },
};
