/**
 * planner.js
 * 할 일(Task) 관리 모듈. v9 계획을 앞당겨 v1에서 기본 기능을 구현했다.
 * 일정/목표/단계별 계획으로의 확장은 이 구조 위에 필드를 추가하는 식으로 가능하다.
 */

const HolmPlanner = (() => {
  const KEY = "holm_planner_tasks_v1";

  function _load() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function _save(tasks) {
    localStorage.setItem(KEY, JSON.stringify(tasks));
  }

  function addTask(text) {
    const tasks = _load();
    const task = { id: Date.now().toString(36), text, done: false, createdAt: new Date().toISOString() };
    tasks.push(task);
    _save(tasks);
    return task;
  }

  function getAll() {
    return _load();
  }

  // 1부터 시작하는 "화면에 보이는 번호"로 완료 처리
  function completeByIndex(index1) {
    const tasks = _load();
    const idx = index1 - 1;
    if (idx < 0 || idx >= tasks.length) return null;
    tasks[idx].done = true;
    _save(tasks);
    return tasks[idx];
  }

  function removeByIndex(index1) {
    const tasks = _load();
    const idx = index1 - 1;
    if (idx < 0 || idx >= tasks.length) return null;
    const [removed] = tasks.splice(idx, 1);
    _save(tasks);
    return removed;
  }

  function clearAll() {
    _save([]);
  }

  return { addTask, getAll, completeByIndex, removeByIndex, clearAll };
})();
