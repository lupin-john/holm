/**
 * tools-calculator.js
 * 안전한 사칙연산 계산기. eval()을 사용하지 않고
 * 숫자/괄호/+-*÷만 허용하는 간단한 재귀 하향 파서를 직접 구현한다.
 */

const CalculatorTool = (() => {
  function safeEvaluate(expr) {
    // 허용 문자만 남기고 전부 제거 (보안)
    const cleaned = expr.replace(/[^0-9+\-*/().\s]/g, "");
    if (!cleaned.trim()) throw new Error("계산할 식이 없습니다.");

    let pos = 0;

    function peek() { return cleaned[pos]; }
    function next() { return cleaned[pos++]; }
    function skipSpace() { while (peek() === " ") pos++; }

    function parseNumber() {
      skipSpace();
      let start = pos;
      if (peek() === "-" || peek() === "+") pos++;
      while (/[0-9.]/.test(peek() || "")) pos++;
      const numStr = cleaned.slice(start, pos);
      if (numStr === "" || numStr === "-" || numStr === "+") {
        throw new Error("숫자 형식이 올바르지 않습니다.");
      }
      return parseFloat(numStr);
    }

    function parseFactor() {
      skipSpace();
      if (peek() === "(") {
        next();
        const val = parseExpression();
        skipSpace();
        if (peek() !== ")") throw new Error("괄호가 맞지 않습니다.");
        next();
        return val;
      }
      return parseNumber();
    }

    function parseTerm() {
      let val = parseFactor();
      skipSpace();
      while (peek() === "*" || peek() === "/") {
        const op = next();
        const rhs = parseFactor();
        if (op === "*") val *= rhs;
        else {
          if (rhs === 0) throw new Error("0으로 나눌 수 없습니다.");
          val /= rhs;
        }
        skipSpace();
      }
      return val;
    }

    function parseExpression() {
      let val = parseTerm();
      skipSpace();
      while (peek() === "+" || peek() === "-") {
        const op = next();
        const rhs = parseTerm();
        val = op === "+" ? val + rhs : val - rhs;
        skipSpace();
      }
      return val;
    }

    const result = parseExpression();
    skipSpace();
    if (pos !== cleaned.length) throw new Error("식을 해석할 수 없습니다.");
    return result;
  }

  const definition = {
    name: "calculator",
    description: "사칙연산(+, -, *, /, 괄호)을 계산합니다. 예: 123*456",
    execute(expr) {
      const value = safeEvaluate(expr);
      return `${expr.trim()} = ${value}`;
    },
  };

  return definition;
})();
