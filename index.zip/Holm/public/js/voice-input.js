/**
 * voice-input.js
 * Web Speech API의 SpeechRecognition을 감싼 음성 입력 모듈.
 * iOS Safari 등 일부 브라우저는 지원하지 않을 수 있어 지원 여부를 확인한다.
 */

const HolmVoiceInput = (() => {
  const SpeechRecognitionCtor =
    window.SpeechRecognition || window.webkitSpeechRecognition || null;

  let recognition = null;
  let listening = false;

  function isSupported() {
    return !!SpeechRecognitionCtor;
  }

  function start({ onResult, onEnd, onError }) {
    if (!isSupported()) {
      onError && onError(new Error("이 브라우저는 음성 인식을 지원하지 않아요."));
      return;
    }
    if (listening) return;

    recognition = new SpeechRecognitionCtor();
    recognition.lang = "ko-KR";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      const text = event.results[0][0].transcript;
      onResult && onResult(text);
    };
    recognition.onerror = (event) => {
      onError && onError(new Error(event.error || "음성 인식 오류"));
    };
    recognition.onend = () => {
      listening = false;
      onEnd && onEnd();
    };

    listening = true;
    recognition.start();
  }

  function stop() {
    if (recognition && listening) recognition.stop();
  }

  return { isSupported, start, stop };
})();
