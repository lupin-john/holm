/**
 * hud.js
 * 상단 상태 칩, Core 아래 캡션, 우측 모듈 상태 패널을 관리.
 */

const HolmHUD = (() => {
  const CAPTIONS = {
    IDLE: "대기 중...",
    LISTENING: "듣고 있어요...",
    THINKING: "생각하는 중...",
    PROCESSING: "처리 중...",
    SPEAKING: "말하는 중...",
    ERROR: "오류 발생",
  };

  // 초기 버전에서 구현된 모듈 / 앞으로 구현될 모듈
  async function _buildModules() {
    const apiMode = window.HolmSettings && HolmSettings.isApiMode();
    const learningOn = window.HolmSettings && HolmSettings.getLearningMode();
    let memCount = 0, knowCount = 0, memOk = true, knowOk = true;
    try { memCount = (await HolmMemoryDB.getAll()).length; } catch (e) { memOk = false; }
    try { knowCount = (await HolmKnowledgeDB.getAll()).length; } catch (e) { knowOk = false; }

    // Local AI 실패 여부는 Memory/Knowledge와 완전히 독립적으로 표시한다
    let brainStatus = apiMode ? "ONLINE (외부 API)" : "ONLINE (내장 AI)";
    if (!apiMode && window.HolmLocalAI) {
      const err = HolmLocalAI.getLastError();
      if (err) brainStatus = `ERROR (${err.code || "로딩 실패"})`;
    }

    return [
      { key: "core", name: "AI CORE", status: "ONLINE" },
      { key: "brain", name: "BRAIN (대화)", status: brainStatus },
      { key: "memory", name: "MEMORY", status: memOk ? `ONLINE (${memCount}개)` : "ERROR" },
      { key: "knowledge", name: "KNOWLEDGE", status: knowOk ? `ONLINE (${knowCount}개)` : "ERROR" },
      { key: "reflection", name: "REFLECTION", status: learningOn ? "ONLINE" : "OFFLINE (Learning Mode 꺼짐)" },
      { key: "chat", name: "CHAT", status: "ONLINE" },
      { key: "voice", name: "VOICE", status: "ONLINE" },
      { key: "calculator", name: "CALCULATOR", status: "ONLINE" },
      { key: "time", name: "TIME/DATE", status: "ONLINE" },
      { key: "search", name: "SEARCH", status: "ONLINE (위키백과)" },
      { key: "files", name: "FILES", status: "ONLINE" },
      { key: "vision", name: "VISION", status: apiMode ? "ONLINE" : "OFFLINE (내장 AI 미지원)" },
      { key: "rag", name: "RAG", status: "ONLINE (키워드 기반)" },
      { key: "planner", name: "PLANNER", status: "ONLINE" },
      { key: "code", name: "CODE ASSIST", status: "OFFLINE" },
    ];
  }

  let chipEl, captionEl, listEl, processFillEl;

  function init() {
    chipEl = document.getElementById("statusChip");
    captionEl = document.getElementById("coreCaption");
    listEl = document.getElementById("moduleList");
    processFillEl = document.getElementById("processMetricFill");

    renderModuleList();

    HolmState.subscribe((s) => {
      updateStatusChip(s);
      updateCaption(s);
      bumpProcessMetric(s);
    });

    // 모듈 패널 열기/닫기
    const panel = document.getElementById("modulesPanel");
    const backdrop = document.getElementById("modulesBackdrop");
    document.getElementById("modulesToggleBtn").addEventListener("click", () => {
      panel.classList.add("open");
      backdrop.classList.add("open");
    });
    const close = () => {
      panel.classList.remove("open");
      backdrop.classList.remove("open");
    };
    document.getElementById("modulesCloseBtn").addEventListener("click", close);
    backdrop.addEventListener("click", close);
  }

  function updateStatusChip(state) {
    chipEl.textContent = state;
    chipEl.classList.toggle("state-error", state === "ERROR");
  }

  function updateCaption(state) {
    captionEl.textContent = CAPTIONS[state] || state;
  }

  function bumpProcessMetric(state) {
    const map = { IDLE: 8, LISTENING: 30, THINKING: 55, PROCESSING: 85, SPEAKING: 40, ERROR: 100 };
    if (processFillEl) processFillEl.style.width = (map[state] ?? 10) + "%";
  }

  async function renderModuleList() {
    listEl.innerHTML = "";
    const modules = await _buildModules();
    modules.forEach((m) => {
      const li = document.createElement("li");
      li.className = "module-item";
      const badgeClass = m.status.startsWith("ONLINE") ? "ONLINE" : m.status.replace(/[^A-Z]/g, "");
      li.innerHTML = `<span>${m.name}</span><span class="module-badge ${badgeClass}">${m.status}</span>`;
      listEl.appendChild(li);
    });
  }

  function setMemoryUsagePercent(pct) {
    const el = document.getElementById("memoryMetricFill");
    if (el) el.style.width = Math.min(100, pct) + "%";
  }

  return { init, setMemoryUsagePercent, renderModuleList };
})();
