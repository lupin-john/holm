/**
 * state.js
 * Holm의 전역 상태 머신.
 * 다른 모든 모듈(Core 애니메이션, HUD, 음성 등)이 이 상태를 구독한다.
 *
 * 상태: IDLE | LISTENING | THINKING | PROCESSING | SPEAKING | ERROR
 */

const HolmState = (() => {
  const STATES = ["IDLE", "LISTENING", "THINKING", "PROCESSING", "SPEAKING", "ERROR"];

  let current = "IDLE";
  const listeners = [];

  function set(next, meta = {}) {
    if (!STATES.includes(next)) {
      console.warn("[HolmState] 알 수 없는 상태:", next);
      return;
    }
    const prev = current;
    current = next;
    listeners.forEach((fn) => {
      try {
        fn(current, prev, meta);
      } catch (e) {
        console.error("[HolmState] 리스너 오류:", e);
      }
    });
  }

  function get() {
    return current;
  }

  function subscribe(fn) {
    listeners.push(fn);
    return () => {
      const i = listeners.indexOf(fn);
      if (i >= 0) listeners.splice(i, 1);
    };
  }

  return { STATES, set, get, subscribe };
})();
