/**
 * memory-ui.js
 * "기억 관리" 패널의 화면 로직 + 저장 토스트 + 사용자 승인 모달.
 * 데이터 작업은 memory-db.js / knowledge-db.js / export-import.js에 위임하고,
 * 여기서는 DOM 렌더링과 이벤트 연결만 담당한다.
 */

const HolmMemoryUI = (() => {
  const TYPE_LABELS = {
    user_preference: "사용자 선호",
    user_fact: "사용자 정보",
    project_fact: "프로젝트",
    instruction: "지시사항",
    important_event: "중요 사건",
    learned_knowledge: "학습된 지식",
    conversation_summary: "대화 요약",
  };

  let listEl, searchInput, toastEl, approvalToastEl, approvalContentEl;
  let approvalQueue = [];
  let toastTimer = null;

  function init() {
    listEl = document.getElementById("memoryList");
    searchInput = document.getElementById("memorySearchInput");
    toastEl = document.getElementById("memoryToast");
    approvalToastEl = document.getElementById("approvalToast");
    approvalContentEl = document.getElementById("approvalContent");

    searchInput.addEventListener("input", () => renderList(searchInput.value.trim()));

    document.getElementById("exportMemoryBtn").addEventListener("click", async () => {
      const n = await HolmExportImport.exportMemory();
      showToast(`기억 ${n}개를 holm-memory.json으로 내보냈어요.`);
    });
    document.getElementById("exportKnowledgeBtn").addEventListener("click", async () => {
      const n = await HolmExportImport.exportKnowledge();
      showToast(`지식 ${n}개를 holm-knowledge.json으로 내보냈어요.`);
    });
    document.getElementById("exportTrainingBtn").addEventListener("click", async () => {
      const n = await HolmExportImport.exportTraining();
      showToast(`대화 ${n}건을 holm-training.jsonl로 내보냈어요.`);
    });

    const importFile = document.getElementById("importMemoryFile");
    document.getElementById("importMemoryBtn").addEventListener("click", () => importFile.click());
    importFile.addEventListener("change", async () => {
      const file = importFile.files[0];
      if (!file) return;
      try {
        const n = await HolmExportImport.importMemory(file);
        showToast(`기억 ${n}개를 가져왔어요.`);
        renderList();
      } catch (e) {
        showToast("가져오기 실패: " + e.message);
      }
      importFile.value = "";
    });

    document.getElementById("clearMemoryBtn").addEventListener("click", async () => {
      if (!confirm("저장된 기억을 전부 삭제할까요? 되돌릴 수 없어요.")) return;
      await HolmMemoryDB.clearAll();
      renderList();
      showToast("모든 기억을 삭제했어요.");
    });

    document.getElementById("approvalAcceptBtn").addEventListener("click", () => _resolveApproval(true));
    document.getElementById("approvalDismissBtn").addEventListener("click", () => _resolveApproval(false));

    HolmBrain.onReflection(({ saved, pending }) => {
      if (saved && saved.length) {
        showToast(`🧠 기억 +${saved.length}개 저장됨`);
        renderList();
      }
      if (pending && pending.length) {
        approvalQueue.push(...pending);
        _showNextApproval();
      }
    });

    renderList();
  }

  function showToast(text) {
    toastEl.textContent = text;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2600);
  }

  function _showNextApproval() {
    if (!approvalQueue.length) {
      approvalToastEl.style.display = "none";
      return;
    }
    const next = approvalQueue[0];
    approvalContentEl.textContent = `[${TYPE_LABELS[next.type] || next.type}] ${next.content}`;
    approvalToastEl.style.display = "";
  }

  async function _resolveApproval(accept) {
    const cand = approvalQueue.shift();
    if (accept && cand) {
      await HolmMemoryDB.addOrMerge(cand);
      showToast("🧠 기억했어요.");
      renderList();
    }
    _showNextApproval();
  }

  async function renderList(query = "") {
    const all = await HolmMemoryDB.getAll();
    const filtered = query
      ? all.filter((m) =>
          (m.content + " " + (m.tags || []).join(" ")).toLowerCase().includes(query.toLowerCase())
        )
      : all;

    if (!filtered.length) {
      listEl.innerHTML = `<p class="memory-empty">${query ? "검색 결과가 없어요." : "아직 저장된 기억이 없어요."}</p>`;
      return;
    }

    // 타입별로 그룹핑해서 보여준다
    const groups = {};
    filtered.forEach((m) => {
      (groups[m.type] = groups[m.type] || []).push(m);
    });

    listEl.innerHTML = "";
    Object.entries(groups).forEach(([type, items]) => {
      const groupEl = document.createElement("div");
      groupEl.className = "memory-group";
      groupEl.innerHTML = `<div class="memory-group-title">[${TYPE_LABELS[type] || type}]</div>`;
      items
        .sort((a, b) => b.importance - a.importance)
        .forEach((m) => groupEl.appendChild(_renderItem(m)));
      listEl.appendChild(groupEl);
    });
  }

  function _renderItem(m) {
    const el = document.createElement("div");
    el.className = "memory-item";
    el.innerHTML = `
      <div class="memory-item-content" data-id="${m.id}">${_escape(m.content)}</div>
      <div class="memory-item-meta">
        중요도 <input type="range" class="memory-importance" data-id="${m.id}" min="0" max="1" step="0.05" value="${m.importance}">
        <span class="memory-importance-val">${m.importance.toFixed(2)}</span>
        <span class="memory-item-source">· ${m.source}</span>
      </div>
      <div class="memory-item-actions">
        <button class="memory-edit-btn" data-id="${m.id}">✏️</button>
        <button class="memory-del-btn" data-id="${m.id}">🗑</button>
      </div>
    `;

    el.querySelector(".memory-importance").addEventListener("input", (e) => {
      el.querySelector(".memory-importance-val").textContent = parseFloat(e.target.value).toFixed(2);
    });
    el.querySelector(".memory-importance").addEventListener("change", async (e) => {
      await HolmMemoryDB.update(m.id, { importance: parseFloat(e.target.value) });
    });

    el.querySelector(".memory-edit-btn").addEventListener("click", () => _startEdit(el, m));
    el.querySelector(".memory-del-btn").addEventListener("click", async () => {
      await HolmMemoryDB.remove(m.id);
      renderList(searchInput.value.trim());
    });

    return el;
  }

  function _startEdit(el, m) {
    const contentEl = el.querySelector(".memory-item-content");
    const textarea = document.createElement("textarea");
    textarea.className = "settings-input memory-edit-textarea";
    textarea.value = m.content;
    contentEl.replaceWith(textarea);
    textarea.focus();

    const save = async () => {
      await HolmMemoryDB.update(m.id, { content: textarea.value.trim() });
      renderList(searchInput.value.trim());
    };
    textarea.addEventListener("blur", save);
    textarea.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        textarea.blur();
      }
    });
  }

  function _escape(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  return { init, renderList, showToast };
})();
