/**
 * knowledge-db.js
 * Memory("사용자에 대한 사실/선호")와는 별도로,
 * 프로젝트/일반 지식을 title+content+category 구조로 저장하는 Knowledge DB.
 *
 * 예: Holm 프로젝트 자체에 대한 설명, 검색 결과 요약, 문서에서 뽑은 지식 등.
 */

const HolmKnowledgeDB = (() => {
  const STORE = "knowledge";

  function _id() {
    return "know_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 7);
  }

  async function add({ title, content, category, source, confidence, tags }) {
    const now = new Date().toISOString();
    const record = {
      id: _id(),
      title,
      content,
      category: category || "general",
      source: source || "conversation",
      confidence: confidence ?? 0.6,
      createdAt: now,
      updatedAt: now,
      tags: tags || [],
    };
    await HolmDB.put(STORE, record);
    return record;
  }

  async function getAll() {
    return HolmDB.getAll(STORE);
  }

  async function update(id, patch) {
    const current = await HolmDB.get(STORE, id);
    if (!current) return null;
    const next = { ...current, ...patch, updatedAt: new Date().toISOString() };
    await HolmDB.put(STORE, next);
    return next;
  }

  async function remove(id) {
    return HolmDB.remove(STORE, id);
  }

  async function clearAll() {
    return HolmDB.clear(STORE);
  }

  async function search(query, topK = 3) {
    const all = await getAll();
    const scored = all
      .map((k) => ({
        k,
        score: HolmTextSim.overlapScore(query, `${k.title} ${k.content} ${(k.tags || []).join(" ")}`),
      }))
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score || b.k.confidence - a.k.confidence);
    return scored.slice(0, topK).map((x) => x.k);
  }

  return { add, getAll, update, remove, clearAll, search };
})();
