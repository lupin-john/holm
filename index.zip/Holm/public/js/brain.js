/**
 * brain.js
 * Holm의 두뇌. 사용자 입력을 받아:
 *   1) 메모리 명령("기억해:", "기억 삭제" 등) 처리 (MemoryDB에 직접 저장)
 *   2) 할 일(Planner) 명령 처리
 *   3) 계산/시간/날짜/검색/문서 명령 처리
 *   4) 그 외에는 Context Retrieval(Memory+Knowledge+RAG) → AI 호출 → Reflection
 *
 * 상태 전이: THINKING → PROCESSING → (완료 후 chat.js가 SPEAKING으로 전환)
 */

const HolmBrain = (() => {
  const TOOLS = [CalculatorTool, TimeTool, DateTool, SearchTool, PlannerTool];
  let reflectionListeners = [];

  function onReflection(fn) {
    reflectionListeners.push(fn);
  }
  function _emitReflection(result) {
    reflectionListeners.forEach((fn) => {
      try { fn(result); } catch (e) { /* noop */ }
    });
  }

  async function handleUserInput(userInput, image = null) {
    HolmState.set("THINKING");
    await _delay(250);

    if (image) {
      if (!VisionTool.isAvailable()) {
        HolmState.set("PROCESSING");
        await _delay(150);
        return VisionTool.unavailableMessage();
      }
      return _callModel(userInput || "이 이미지를 설명해줘.", image);
    }

    const memoryReply = await _tryHandleMemoryCommand(userInput);
    if (memoryReply !== null) {
      HolmState.set("PROCESSING");
      await _delay(200);
      return memoryReply;
    }

    const plannerReply = PlannerTool.tryHandle(userInput.trim());
    if (plannerReply !== null) {
      HolmState.set("PROCESSING");
      await _delay(200);
      return plannerReply;
    }

    const docReply = _tryHandleDocCommand(userInput);
    if (docReply !== null) {
      HolmState.set("PROCESSING");
      await _delay(200);
      return docReply;
    }

    const toolReply = await _tryHandleTool(userInput);
    if (toolReply !== null) {
      HolmState.set("PROCESSING");
      await _delay(200);
      return toolReply;
    }

    return _callModel(userInput, null);
  }

  async function _callModel(userInput, image) {
    HolmState.set("PROCESSING");

    const systemPrompt = HolmPrompt.buildSystemPrompt({ userName: null, holmName: "Holm" });
    const context = await HolmRetrieval.getContext(userInput);

    const payload = HolmPrompt.buildMessages({
      systemPrompt,
      memories: context.memories,
      knowledge: context.knowledge,
      ragChunks: context.ragChunks,
      history: HolmStorage.loadHistory(),
      userInput,
    });
    payload.image = image;

    try {
      const rawReply = await HolmModelAdapter.generateReply(payload);
      const { visibleText, saved, pending } = await HolmReflection.reflect(userInput, rawReply);

      if (saved.length || pending.length) {
        _emitReflection({ saved, pending });
      }

      // 이번 대화를 관련 기억 id와 함께 로그에 남긴다 (LoRA 준비용)
      HolmConversationLog.record({
        userMessage: userInput,
        holmResponse: visibleText,
        relatedMemoryIds: context.memories.map((m) => m.id),
        relatedKnowledgeIds: context.knowledge.map((k) => k.id),
      }).catch(() => {});

      return visibleText;
    } catch (e) {
      HolmState.set("ERROR");
      console.error("[HolmBrain] 모델 호출 실패:", e);
      return e.message || "죄송해요, 답변을 생성하는 중 오류가 발생했어요.";
    }
  }

  async function _tryHandleMemoryCommand(input) {
    const text = input.trim();

    const addMatch = text.match(/^(?:이 내용을\s*)?기억해\s*[:：]?\s*(.+)$/i) || text.match(/^(.+)\s*기억해줘\s*$/i);
    if (addMatch && addMatch[1]) {
      const { record } = await HolmMemoryDB.addOrMerge({
        type: "user_fact",
        content: addMatch[1].trim(),
        importance: 0.8,
        confidence: 0.95,
        source: "user_explicit",
        tags: ["explicit"],
      });
      _emitReflection({ saved: [record], pending: [] });
      return `기억했어요: "${addMatch[1].trim()}"`;
    }

    if (/^기억\s*(목록|조회|보여줘)/.test(text)) {
      const list = await HolmMemoryDB.getAll();
      if (!list.length) return "아직 저장된 기억이 없어요.";
      return "저장된 기억이에요:\n" + list.map((m, i) => `${i + 1}. [${m.type}] ${m.content}`).join("\n");
    }

    if (/^기억\s*(전체\s*)?(삭제|초기화)/.test(text)) {
      await HolmMemoryDB.clearAll();
      return "모든 기억을 초기화했어요.";
    }

    return null;
  }

  function _tryHandleDocCommand(input) {
    const text = input.trim();
    if (/^문서\s*목록/.test(text)) {
      const docs = HolmRAG.listDocuments();
      if (!docs.length) return "저장된 문서가 없어요. 📁 버튼으로 텍스트 파일을 올려보세요.";
      return "저장된 문서예요:\n" + docs.map((d, i) => `${i + 1}. ${d.filename}`).join("\n");
    }
    if (/^문서\s*(전체\s*)?(삭제|초기화)/.test(text)) {
      HolmRAG.clearAll();
      return "저장된 문서를 모두 삭제했어요.";
    }
    return null;
  }

  async function _tryHandleTool(input) {
    const text = input.trim();

    const calcMatch = text.match(/^계산\s*(.+)$/) || (/^[0-9+\-*/().\s]+$/.test(text) && text.length > 1 ? [null, text] : null);
    if (calcMatch) {
      try { return CalculatorTool.execute(calcMatch[1]); } catch (e) { return `계산할 수 없어요: ${e.message}`; }
    }
    if (/지금\s*몇\s*시|현재\s*시간|몇시야/.test(text)) return TimeTool.execute();
    if (/오늘\s*날짜|오늘\s*며칠|날짜가\s*뭐/.test(text)) return DateTool.execute();

    const searchMatch = text.match(/^검색\s*[:：]?\s*(.+)$/);
    if (searchMatch) return await SearchTool.execute(searchMatch[1]);

    return null;
  }

  function _delay(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  return { handleUserInput, onReflection };
})();
