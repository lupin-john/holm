/**
 * export-import.js
 * Memory/Knowledge를 JSON으로 내보내고 불러오는 기능.
 * 그리고 향후 LoRA 학습을 위한 대화 로그 JSONL 다운로드.
 */

const HolmExportImport = (() => {
  function _download(filename, content, mime = "application/json") {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async function exportMemory() {
    const memories = await HolmMemoryDB.getAll();
    _download("holm-memory.json", JSON.stringify(memories, null, 2));
    return memories.length;
  }

  async function exportKnowledge() {
    const knowledge = await HolmKnowledgeDB.getAll();
    _download("holm-knowledge.json", JSON.stringify(knowledge, null, 2));
    return knowledge.length;
  }

  async function exportTraining() {
    const jsonl = await HolmConversationLog.exportTrainingJsonl();
    _download("holm-training.jsonl", jsonl, "application/jsonl");
    return jsonl ? jsonl.split("\n").length : 0;
  }

  /** @param {File} file */
  function _readFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  }

  async function importMemory(file) {
    const text = await _readFile(file);
    const list = JSON.parse(text);
    if (!Array.isArray(list)) throw new Error("올바른 형식이 아니에요 (배열이어야 해요).");
    for (const item of list) {
      await HolmDB.put("memories", item);
    }
    return list.length;
  }

  async function importKnowledge(file) {
    const text = await _readFile(file);
    const list = JSON.parse(text);
    if (!Array.isArray(list)) throw new Error("올바른 형식이 아니에요 (배열이어야 해요).");
    for (const item of list) {
      await HolmDB.put("knowledge", item);
    }
    return list.length;
  }

  return { exportMemory, exportKnowledge, exportTraining, importMemory, importKnowledge };
})();
