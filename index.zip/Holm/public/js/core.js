/**
 * core.js
 * Holm Core: 중앙 nucleus + 여러 궤도의 electron이 계속 회전하는
 * Canvas 애니메이션. HolmState를 구독해서 상태별로 속도/밝기가 변한다.
 */

const HolmCore = (() => {
  let canvas, ctx;
  let W, H, CX, CY;
  let rafId = null;
  let t = 0; // 애니메이션 타임라인

  // 상태별 튜닝 값 (속도 배율, 밝기, nucleus pulse 강도)
  const STATE_PROFILE = {
    IDLE:       { speed: 0.35, glow: 0.6, pulse: 0.5, color: "#4df3ff" },
    LISTENING:  { speed: 0.55, glow: 0.85, pulse: 0.9, color: "#4df3ff" },
    THINKING:   { speed: 1.4,  glow: 1.0, pulse: 1.2, color: "#7ad8ff" },
    PROCESSING: { speed: 2.2,  glow: 1.15, pulse: 1.4, color: "#3a6dff" },
    SPEAKING:   { speed: 0.9,  glow: 1.1, pulse: 1.8, color: "#4df3ff" },
    ERROR:      { speed: 0.6,  glow: 1.0, pulse: 1.0, color: "#ff4d6d" },
  };

  let profile = STATE_PROFILE.IDLE;

  // 궤도 정의: 반지름 비율, 기울기(타원 축소율), 회전 속도, 시작 각도
  const orbits = [
    { rRatio: 0.42, tilt: 0.35, speed: 1.6, phase: 0 },
    { rRatio: 0.58, tilt: 0.6, speed: -1.1, phase: 2.1 },
    { rRatio: 0.74, tilt: 0.2, speed: 0.8, phase: 4.2 },
  ];

  // 배경 미세 입자
  let particles = [];

  function init(canvasEl) {
    canvas = canvasEl;
    ctx = canvas.getContext("2d");
    resize();
    window.addEventListener("resize", resize);

    particles = Array.from({ length: 24 }, () => spawnParticle());

    HolmState.subscribe((s) => {
      profile = STATE_PROFILE[s] || STATE_PROFILE.IDLE;
    });

    start();
  }

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    W = rect.width;
    H = rect.height;
    CX = W / 2;
    CY = H / 2;
  }

  function spawnParticle() {
    const ang = Math.random() * Math.PI * 2;
    const dist = Math.random();
    return {
      angle: ang,
      dist,
      speed: 0.05 + Math.random() * 0.15,
      size: 0.6 + Math.random() * 1.4,
      alpha: 0.2 + Math.random() * 0.4,
    };
  }

  function start() {
    if (rafId) return;
    const loop = () => {
      t += 0.016 * profile.speed;
      draw();
      rafId = requestAnimationFrame(loop);
    };
    rafId = requestAnimationFrame(loop);
  }

  function stop() {
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    const R = Math.min(W, H) / 2 - 6;

    drawHUDRings(R);
    drawOrbits(R);
    drawParticles(R);
    drawNucleus(R);
  }

  function drawHUDRings(R) {
    ctx.save();
    ctx.translate(CX, CY);
    for (let i = 0; i < 2; i++) {
      const rad = R * (0.92 - i * 0.08);
      ctx.rotate((i % 2 === 0 ? 1 : -1) * 0.004 * profile.speed);
      ctx.beginPath();
      ctx.strokeStyle = `rgba(77,243,255,${0.15 - i * 0.05})`;
      ctx.lineWidth = 1;
      const dashLen = 6;
      const gapLen = 10;
      let a = t * (i === 0 ? 0.6 : -0.4);
      for (let seg = 0; seg < 40; seg++) {
        const a0 = a + seg * (dashLen + gapLen) / rad;
        const a1 = a0 + dashLen / rad;
        ctx.moveTo(rad * Math.cos(a0), rad * Math.sin(a0));
        ctx.arc(0, 0, rad, a0, a1);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawOrbits(R) {
    orbits.forEach((orbit, idx) => {
      const rad = R * orbit.rRatio;
      ctx.save();
      ctx.translate(CX, CY);

      // 궤도 타원 라인 (은은한 glow)
      ctx.beginPath();
      ctx.ellipse(0, 0, rad, rad * (1 - orbit.tilt), orbit.phase, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(77,243,255,${0.18 * profile.glow})`;
      ctx.lineWidth = 1;
      ctx.stroke();

      // electron 위치 계산
      const angle = t * orbit.speed + orbit.phase;
      const ex = rad * Math.cos(angle);
      const ey = rad * (1 - orbit.tilt) * Math.sin(angle);
      // 궤도 기울기(phase) 만큼 회전 적용된 좌표계이므로 그대로 그리면 됨
      ctx.rotate(orbit.phase * 0); // 이미 ellipse 자체에 회전 적용됨 (phase)

      // 실제로 궤도 기울기를 시각적으로 표현하기 위해 ellipse의 rotation을 사용했으므로
      // electron도 동일한 rotation 좌표계에서 계산
      const rotAngle = orbit.phase;
      const localX = rad * Math.cos(angle);
      const localY = rad * (1 - orbit.tilt) * Math.sin(angle);
      const worldX = localX * Math.cos(rotAngle) - localY * Math.sin(rotAngle);
      const worldY = localX * Math.sin(rotAngle) + localY * Math.cos(rotAngle);

      // electron glow
      const grad = ctx.createRadialGradient(worldX, worldY, 0, worldX, worldY, 10 * profile.glow);
      grad.addColorStop(0, "rgba(255,255,255,0.95)");
      grad.addColorStop(0.3, profile.color);
      grad.addColorStop(1, "rgba(77,243,255,0)");
      ctx.beginPath();
      ctx.fillStyle = grad;
      ctx.arc(worldX, worldY, 9 * profile.glow, 0, Math.PI * 2);
      ctx.fill();

      // electron core (밝은 점)
      ctx.beginPath();
      ctx.fillStyle = "#ffffff";
      ctx.arc(worldX, worldY, 2.6, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    });
  }

  function drawParticles(R) {
    ctx.save();
    ctx.translate(CX, CY);
    particles.forEach((p) => {
      p.angle += p.speed * 0.02 * profile.speed;
      const r = R * (0.3 + p.dist * 0.9);
      const x = r * Math.cos(p.angle);
      const y = r * Math.sin(p.angle);
      ctx.beginPath();
      ctx.fillStyle = `rgba(77,243,255,${p.alpha * 0.5 * profile.glow})`;
      ctx.arc(x, y, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  function drawNucleus(R) {
    const pulse = 1 + Math.sin(t * 3 * profile.pulse) * 0.08 * profile.pulse;
    const baseR = R * 0.16 * pulse;

    ctx.save();
    ctx.translate(CX, CY);

    // 바깥 에너지 아우라
    const aura = ctx.createRadialGradient(0, 0, baseR * 0.4, 0, 0, baseR * 3.2 * profile.glow);
    aura.addColorStop(0, `rgba(77,243,255,${0.5 * profile.glow})`);
    aura.addColorStop(1, "rgba(77,243,255,0)");
    ctx.beginPath();
    ctx.fillStyle = aura;
    ctx.arc(0, 0, baseR * 3.2 * profile.glow, 0, Math.PI * 2);
    ctx.fill();

    // nucleus 본체
    const core = ctx.createRadialGradient(0, 0, 0, 0, 0, baseR);
    core.addColorStop(0, "#ffffff");
    core.addColorStop(0.4, profile.color);
    core.addColorStop(1, "rgba(58,109,255,0.7)");
    ctx.beginPath();
    ctx.fillStyle = core;
    ctx.arc(0, 0, baseR, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  return { init, start, stop };
})();
