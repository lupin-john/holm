/**
 * tools-time.js
 * 사용자의 로컬 시간대를 기준으로 현재 시각을 알려주는 도구.
 */

const TimeTool = {
  name: "time",
  description: "현재 시각을 알려줍니다.",
  execute() {
    const now = new Date();
    const h = now.getHours();
    const m = String(now.getMinutes()).padStart(2, "0");
    const period = h < 12 ? "오전" : "오후";
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return `지금은 ${period} ${h12}시 ${m}분이에요.`;
  },
};
