/**
 * memory-db.js
 * Holm v3의 장기 기억 시스템.
 *
 * 기존 memory.js("기억해:" 한 줄 저장)를 대체/확장한다.
 * 각 기억은 타입(type)·중요도(importance)·신뢰도(confidence)를 가지고,
 * 비슷한 내용이 이미 있으면 새로 만들지 않고 기존 것을 업데이트한다.
 *
 * type: user_preference | user_fact | project_fact | instruction
 *     | important_event | learned_knowledge | conversation_summary
 */

const HolmMemoryDB = (() => {
  const STORE = "memories";
  const DUPLICATE_THRESHOLD = 0.55; // 이 이상 겹치면 "같은 기억"으로 취급

  function _id() {
    return "mem_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 7);
  }

  /**
   * @param {{type,content,importance,confidence,source,tags}} input
   * @returns {Promise<{record, isNew:boolean}>}
   */
  async function addOrMerge(input) {
    const existing = await getAll();
    const dup = existing
      .filter((m) => m.type === input.type)
      .map((m) => ({ m, score: HolmTextSim.jaccard(m.content, input.content) }))
      .sort((a, b) => b.score - a.score)[0];

    const now = new Date().toISOString();

    if (dup && dup.score >= DUPLICATE_THRESHOLD) {
      // 기존 기억 업데이트 (내용 갱신, 중요도는 더 큰 값 유지, lastUsedAt 갱신)
      const merged = {
        ...dup.m,
        content: input.content, // 더 최신 표현으로 교체
        importance: Math.max(dup.m.importance, input.importance ?? dup.m.importance),
        confidence: Math.max(dup.m.confidence, input.confidence ?? dup.m.confidence),
        updatedAt: now,
        lastUsedAt: now,
        tags: Array.from(new Set([...(dup.m.tags || []), ...(input.tags || [])])),
      };
      await HolmDB.put(STORE, merged);
      return { record: merged, isNew: false };
    }

    const record = {
      id: _id(),
      type: input.type,
      content: input.content,
      importance: input.importance ?? 0.5,
      confidence: input.confidence ?? 0.7,
      source: input.source || "user",
      createdAt: now,
      updatedAt: now,
      lastUsedAt: now,
      tags: input.tags || [],
    };
    await HolmDB.put(STORE, record);
    return { record, isNew: true };
  }

  async function getAll() {
    return HolmDB.getAll(STORE);
  }

  async function getById(id) {
    return HolmDB.get(STORE, id);
  }

  async function update(id, patch) {
    const current = await HolmDB.get(STORE, id);
    if (!current) return null;
    const next = { ...current, ...patch, updatedAt: new Date().toISOString() };
    await HolmDB.put(STORE, next);
    return next;
  }

  async function touchUsed(id) {
    const current = await HolmDB.get(STORE, id);
    if (!current) return;
    current.lastUsedAt = new Date().toISOString();
    await HolmDB.put(STORE, current);
  }

  async function remove(id) {
    return HolmDB.remove(STORE, id);
  }

  async function clearAll() {
    return HolmDB.clear(STORE);
  }

  async function search(query, topK = 5) {
    const all = await getAll();
    const scored = all
      .map((m) => ({ m, score: HolmTextSim.overlapScore(query, m.content + " " + (m.tags || []).join(" ")) }))
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score || b.m.importance - a.m.importance);
    return scored.slice(0, topK).map((x) => x.m);
  }

  return { addOrMerge, getAll, getById, update, touchUsed, remove, clearAll, search };
})();
