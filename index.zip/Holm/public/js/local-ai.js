/**
 * local-ai.js
 * Holm에 내장되는 오픈소스 소형 언어모델 (Qwen2.5-Instruct, transformers.js).
 *
 * v3.3: "다운로드는 끝났는데 채팅 보내면 다시 실패" 문제 대응.
 *
 * 이번에 새로 확인/수정한 것:
 *   1) fetch 추적을 로딩 단계뿐 아니라 generate() 호출 자체에도 씌운다.
 *      (onnxruntime-web은 실제 첫 inference 때 WASM 백엔드를 지연 초기화하는
 *       경우가 있어서, "다운로드 완료" 이후에도 첫 generate()에서 추가
 *       네트워크 요청이 발생하며 실패할 수 있다 — 이걸 놓치지 않는다.)
 *   2) Safari/iOS에서는 onnxruntime-web의 멀티스레드+워커(proxy) 경로를
 *      쓰지 않도록 명시적으로 강제한다 (numThreads=1, proxy=false).
 *      이 멀티스레드 경로는 SharedArrayBuffer/Cross-Origin-Isolation이
 *      필요한데, 일반 정적 페이지는 그 헤더가 없어서 Safari에서 조용히
 *      깨지는 경우가 흔하다 — 잘 알려진 호환성 문제라 추측이 아니라
 *      실제로 적용 가능한 수정이다.
 *   3) 페이지가 iOS에 의해 백그라운드에서 리로드됐는지(=메모리에 있던
 *      파이프라인이 날아갔는지)를 감지해서 진단에 남긴다.
 *   4) 원본 Error(name/message/stack/cause)를 끝까지 보존한다.
 */

const HolmLocalAI = (() => {
  const TRANSFORMERS_CDN = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.0";
  const CDN_IMPORT_TIMEOUT_MS = 20000;
  const GENERATE_TIMEOUT_MS = 60000;
  const DTYPE_FALLBACK_CHAIN = ["q4", "q8", "fp32"];

  let statusListeners = [];
  let stageLog = [];
  let fileLog = [];
  let lastError = null;
  let cachedEnv = null;
  let pipelineInstance = null;
  let loadedInfo = { modelId: null, device: null, dtype: null, downloadedBytes: 0 };
  let loadPromise = null;
  let loadCount = 0; // ensureLoaded가 "새로" 실행된 횟수 (캐시 재사용이면 안 늘어남)
  let pageLoadedAt = Date.now();

  // ===== 상태 이벤트 =====
  function onStatus(fn) { statusListeners.push(fn); }
  function _emit(s) { statusListeners.forEach((fn) => { try { fn(s); } catch (e) { /* noop */ } }); }

  function _pushStage(stage, status, detail) {
    const entry = { stage, status, at: new Date().toISOString(), detail: detail || null };
    stageLog.push(entry);
    _emit({ phase: "stage", ...entry });
    return entry;
  }

  function resetLogs() {
    stageLog = [];
    fileLog = [];
  }

  // ===== 오류를 절대 잃어버리지 않기 위한 헬퍼 =====
  function _fullDetail(e, extra = {}) {
    const cause = e && e.cause ? e.cause : null;
    return {
      name: (e && e.name) || "Error",
      message: (e && e.message) || String(e),
      stack: e && e.stack ? String(e.stack).slice(0, 800) : null,
      cause: cause ? { name: cause.name || "Error", message: cause.message || String(cause) } : null,
      ...extra,
    };
  }

  function _wrapError(message, stage, cause, name) {
    const err = new Error(message);
    if (name) err.name = name;
    err.cause = cause;
    err._stage = stage;
    return err;
  }

  // ===== 환경 진단 =====
  function _detectBrowser() {
    const ua = navigator.userAgent || "";
    const isIOS = /iP(hone|od|ad)/.test(navigator.platform || "") ||
      (/Mac/.test(navigator.platform || "") && navigator.maxTouchPoints > 1);
    const isSafari = /^((?!chrome|android|crios|fxios).)*safari/i.test(ua);
    return { isIOS, isSafari, ua };
  }

  async function _checkWasm() {
    try {
      if (typeof WebAssembly !== "object") return false;
      const bytes = new Uint8Array([0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00]);
      await WebAssembly.instantiate(bytes);
      return true;
    } catch (e) {
      return false;
    }
  }

  async function _checkWebGPU() {
    try {
      if (!navigator.gpu) return false;
      const withTimeout = Promise.race([
        navigator.gpu.requestAdapter(),
        new Promise((resolve) => setTimeout(() => resolve(null), 3000)),
      ]);
      const adapter = await withTimeout;
      return !!adapter;
    } catch (e) {
      return false;
    }
  }

  function _navigationInfo() {
    try {
      const nav = performance.getEntriesByType("navigation")[0];
      return {
        type: nav ? nav.type : "unknown", // "navigate" | "reload" | "back_forward" | "prerender"
        secondsSincePageLoad: Math.round((Date.now() - pageLoadedAt) / 1000),
        crossOriginIsolated: typeof crossOriginIsolated !== "undefined" ? crossOriginIsolated : "unknown",
      };
    } catch (e) {
      return { type: "unknown", secondsSincePageLoad: null, crossOriginIsolated: "unknown" };
    }
  }

  async function diagnoseEnvironment(forceRefresh = false) {
    if (cachedEnv && !forceRefresh) return cachedEnv;
    const { isIOS, isSafari, ua } = _detectBrowser();
    const [wasmOk, webgpuOk] = await Promise.all([_checkWasm(), _checkWebGPU()]);
    cachedEnv = {
      browser: isSafari ? "Safari" : ua.includes("Chrome") ? "Chrome" : ua.includes("Firefox") ? "Firefox" : "Other",
      platform: isIOS ? "iPhone/iPad" : (navigator.platform || "Unknown"),
      isIOS,
      isSafari,
      webgpu: webgpuOk ? "available" : "unavailable",
      wasm: wasmOk ? "available" : "unavailable",
      worker: typeof Worker !== "undefined" ? "available" : "unavailable",
      indexedDB: "indexedDB" in window ? "available" : "unavailable",
      navigation: _navigationInfo(),
    };
    return cachedEnv;
  }

  function _chooseDevice(env) {
    if (env.isSafari || env.isIOS) return "wasm";
    if (env.webgpu === "available") return "webgpu";
    return "wasm";
  }

  function _withTimeout(promise, ms, label) {
    return Promise.race([
      promise,
      new Promise((_, reject) =>
        setTimeout(() => reject(_wrapError(`${label} 처리 시간이 ${ms}ms를 넘어서 중단했어요.`, "timeout", null, "HolmTimeoutError")), ms)
      ),
    ]);
  }

  // ===== fetch 가로채기 (로딩 + generate 양쪽에서 재사용) =====
  function _installFetchTracker() {
    const original = window.fetch;
    window.fetch = async function (input, init) {
      const url = typeof input === "string" ? input : input?.url || String(input);
      const isRelevant = /huggingface\.co|jsdelivr\.net|hf\.co/i.test(url);
      let entry = null;
      if (isRelevant) {
        entry = { url, fileName: url.split("/").pop().split("?")[0], status: "start", startedAt: Date.now() };
        fileLog.push(entry);
        _emit({ phase: "file", ...entry });
      }
      try {
        const res = await original(input, init);
        if (entry) {
          entry.status = res.ok ? "success" : "failed";
          entry.httpStatus = res.status;
          const len = res.headers.get("content-length");
          entry.bytes = len ? parseInt(len, 10) : null;
          entry.endedAt = Date.now();
          _emit({ phase: "file", ...entry });
        }
        return res;
      } catch (e) {
        if (entry) {
          entry.status = "failed";
          entry.error = e.message;
          entry.endedAt = Date.now();
          _emit({ phase: "file", ...entry });
        }
        throw e;
      }
    };
    return () => { window.fetch = original; };
  }

  async function _importTransformers() {
    _pushStage("cdn_import", "start");
    try {
      const mod = await _withTimeout(import(TRANSFORMERS_CDN), CDN_IMPORT_TIMEOUT_MS, "cdn_import");
      _pushStage("cdn_import", "success");

      // Safari/iOS 호환성: 멀티스레드+워커(proxy) WASM 경로를 끈다.
      // 이 경로는 SharedArrayBuffer + Cross-Origin-Isolation이 필요한데
      // 일반 정적 페이지는 그 헤더가 없어서 Safari에서 조용히 실패하는
      // 경우가 잘 알려져 있다.
      try {
        const env = cachedEnv;
        if (mod.env?.backends?.onnx?.wasm && env && (env.isSafari || env.isIOS)) {
          mod.env.backends.onnx.wasm.numThreads = 1;
          mod.env.backends.onnx.wasm.proxy = false;
          _pushStage("backend_config", "success", { numThreads: 1, proxy: false, reason: "Safari/iOS 호환성" });
        } else {
          _pushStage("backend_config", "success", { reason: "기본값 유지" });
        }
      } catch (e) {
        _pushStage("backend_config", "failed", _fullDetail(e));
      }

      return mod;
    } catch (e) {
      _pushStage("cdn_import", "failed", _fullDetail(e));
      throw _wrapError("Transformers.js를 불러오지 못했어요 (CDN import 실패)", "cdn_import", e);
    }
  }

  // ===== 실제 로딩 (pipeline API 사용) =====
  async function _ensureLoadedInternal(modelId) {
    resetLogs();
    loadCount++;
    const restoreFetch = _installFetchTracker();

    try {
      const env = await diagnoseEnvironment(true);
      const device = _chooseDevice(env);
      loadedInfo.device = device;
      _pushStage("env-check", "success", env);
      _emit({ phase: "env-check", env, device });

      if (env.wasm === "unavailable" && device === "wasm") {
        throw _wrapError("이 브라우저는 WASM을 지원하지 않아요.", "wasm_check", null);
      }

      const { pipeline } = await _importTransformers();

      _pushStage("pipeline_create", "start");
      _emit({ phase: "start", device, modelId });

      let lastAttemptError = null;
      for (const dtype of DTYPE_FALLBACK_CHAIN) {
        _pushStage(`model_download[${dtype}]`, "start");
        try {
          const generator = await pipeline("text-generation", modelId, {
            dtype,
            device,
            progress_callback: (p) => {
              if (p.status === "progress" && p.total) {
                loadedInfo.downloadedBytes = Math.max(loadedInfo.downloadedBytes, p.total);
                const pct = Math.round((p.loaded / p.total) * 100);
                _emit({ phase: "downloading", pct, file: p.file, dtype, device, totalBytes: p.total });
              }
            },
          });
          _pushStage(`model_download[${dtype}]`, "success");
          _pushStage("pipeline_create", "success");

          pipelineInstance = generator;
          loadedInfo.modelId = modelId;
          loadedInfo.dtype = dtype;
          lastError = null;
          _pushStage("ready", "success");
          _emit({ phase: "ready", device, dtype });
          return generator;
        } catch (e) {
          _pushStage(`model_download[${dtype}]`, "failed", _fullDetail(e));
          console.warn(`[HolmLocalAI] dtype=${dtype} 실패, 다음 옵션 시도:`, e);
          lastAttemptError = e;
        }
      }
      _pushStage("pipeline_create", "failed", _fullDetail(lastAttemptError));
      throw _wrapError("모델 파일을 불러오지 못했어요 (모든 dtype 옵션 실패)", "model_download", lastAttemptError);
    } catch (e) {
      const stage = e._stage || "unknown";
      const rootCause = e.cause || e;
      const detail = _fullDetail(rootCause, { stage, backend: loadedInfo.device, modelId, topMessage: e.message });
      lastError = detail;

      console.error("[HolmLocalAI] === 로딩 실패 상세 ===", {
        stage, error: detail, stageLog: [...stageLog], fileLog: [...fileLog], env: cachedEnv,
      });

      _emit({ phase: "error", ...detail, stageLog: [...stageLog], fileLog: [...fileLog] });
      throw _wrapError(e.message, stage, rootCause, rootCause?.name);
    } finally {
      restoreFetch();
    }
  }

  function ensureLoaded(modelId) {
    if (loadPromise && loadedInfo.modelId === modelId) {
      _pushStage("cache", "success", { note: "이미 불러온 파이프라인을 재사용함 (새로 로딩하지 않음)" });
      return loadPromise;
    }
    // 캐시가 없다 = 방금 다운로드했는데도 이 시점에 처음부터 다시 불러온다면,
    // 페이지가 그 사이 리로드됐을 가능성이 높다는 신호다.
    if (loadCount > 0) {
      _pushStage("cache_miss", "failed", {
        note: "이전에 불러온 적이 있는데도 캐시가 비어있음 — 페이지가 백그라운드에서 리로드되어 메모리 상태가 초기화됐을 가능성이 있어요.",
        navigation: _navigationInfo(),
      });
    }
    loadPromise = _ensureLoadedInternal(modelId).catch((err) => {
      loadPromise = null;
      throw err;
    });
    return loadPromise;
  }

  function isReady(modelId) {
    return loadedInfo.modelId === modelId && !!pipelineInstance;
  }

  function getLastError() { return lastError; }
  function getLoadedInfo() { return { ...loadedInfo, loadCount }; }
  function getDiagnosticsReport() {
    return {
      env: cachedEnv,
      stages: [...stageLog],
      files: [...fileLog],
      lastError,
      loadedInfo: { ...loadedInfo, loadCount },
      navigation: _navigationInfo(),
    };
  }

  async function generate({ system, history, userInput, modelId }) {
    const wasAlreadyLoaded = loadPromise && loadedInfo.modelId === modelId;
    _pushStage("generate", "start", { fromCache: !!wasAlreadyLoaded });

    // generate() 자체도 fetch를 발생시킬 수 있으므로(지연 초기화) 계속 추적한다.
    const restoreFetch = _installFetchTracker();
    try {
      const generator = await ensureLoaded(modelId);

      const messages = [{ role: "system", content: system }];
      (history || []).slice(-10).forEach((m) => {
        messages.push({ role: m.role === "user" ? "user" : "assistant", content: m.text });
      });
      messages.push({ role: "user", content: userInput });

      const output = await _withTimeout(
        generator(messages, { max_new_tokens: 300, temperature: 0.7, top_k: 40, do_sample: true }),
        GENERATE_TIMEOUT_MS,
        "generate"
      );
      _pushStage("generate", "success");
      const last = output[0].generated_text.at(-1);
      return (last && last.content) || "";
    } catch (e) {
      _pushStage("generate", "failed", _fullDetail(e));
      const rootCause = e.cause || e;
      const detail = _fullDetail(rootCause, { stage: "generate", wasAlreadyLoaded: !!wasAlreadyLoaded });
      lastError = detail;
      console.error("[HolmLocalAI] === 생성 실패 상세 ===", {
        error: detail,
        wasAlreadyLoaded: !!wasAlreadyLoaded,
        stageLog: [...stageLog],
        fileLog: [...fileLog],
      });
      _emit({ phase: "error", ...detail, stageLog: [...stageLog], fileLog: [...fileLog] });
      throw _wrapError(e.message || "생성 중 오류가 발생했어요.", "generate", rootCause, rootCause?.name);
    } finally {
      restoreFetch();
    }
  }

  // ===== 개별 진단 테스트 버튼 =====
  async function testCDN() {
    const t0 = performance.now();
    try {
      await _withTimeout(import(TRANSFORMERS_CDN), CDN_IMPORT_TIMEOUT_MS, "cdn_test");
      return { ok: true, ms: Math.round(performance.now() - t0) };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testWasm() {
    const ok = await _checkWasm();
    return { ok };
  }

  async function testHFConnectivity(modelId) {
    const url = `https://huggingface.co/${modelId}/resolve/main/config.json`;
    const t0 = performance.now();
    try {
      const res = await fetch(url);
      const text = await res.text();
      return { ok: res.ok, httpStatus: res.status, ms: Math.round(performance.now() - t0), bytes: text.length };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testTokenizer(modelId) {
    const savedLog = fileLog;
    fileLog = [];
    const restore = _installFetchTracker();
    try {
      const { AutoTokenizer } = await import(TRANSFORMERS_CDN);
      await AutoTokenizer.from_pretrained(modelId);
      const files = [...fileLog];
      return { ok: true, files: files.filter((f) => /tokenizer/i.test(f.fileName)) };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e), files: [...fileLog] };
    } finally {
      restore();
      fileLog = savedLog;
    }
  }

  async function testModelFile(modelId, device) {
    const savedLog = fileLog;
    fileLog = [];
    const restore = _installFetchTracker();
    try {
      const { AutoModelForCausalLM } = await import(TRANSFORMERS_CDN);
      let lastErr = null;
      for (const dtype of DTYPE_FALLBACK_CHAIN) {
        try {
          await AutoModelForCausalLM.from_pretrained(modelId, { dtype, device: device || "wasm" });
          const files = [...fileLog];
          return { ok: true, dtype, files };
        } catch (e) {
          lastErr = e;
        }
      }
      return { ok: false, detail: _fullDetail(lastErr), files: [...fileLog] };
    } finally {
      restore();
      fileLog = savedLog;
    }
  }

  async function testPipeline(modelId) {
    try {
      await ensureLoaded(modelId);
      return { ok: true };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e.cause || e) };
    }
  }

  async function testGenerate(modelId) {
    try {
      const text = await generate({ system: "너는 테스트용 봇이다. 아주 짧게 답해라.", history: [], userInput: "안녕", modelId });
      return { ok: !!text, text };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e.cause || e) };
    }
  }

  return {
    generate, ensureLoaded, isReady, onStatus, diagnoseEnvironment, resetLogs,
    getLastError, getLoadedInfo, getDiagnosticsReport,
    testCDN, testWasm, testHFConnectivity, testTokenizer, testModelFile, testPipeline, testGenerate,
  };
})();
