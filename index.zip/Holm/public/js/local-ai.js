/**
 * local-ai.js
 * Holm에 내장되는 오픈소스 소형 언어모델 (Qwen2.5-Instruct, transformers.js).
 *
 * v3.2: "Load failed" 뒤에 숨어있던 진짜 오류를 끝까지 추적한다.
 *   - fetch()를 임시로 가로채서 실제로 어떤 파일을(URL) 요청했고,
 *     HTTP 상태/바이트 크기/성공-실패를 그대로 기록한다 (추측 아님, 실측).
 *   - 각 로딩 단계(CDN import / 모델 로딩 / 생성)를 START/SUCCESS/FAILED로 기록한다.
 *   - 원본 Error 객체를 절대 버리지 않는다: name/message/stack/cause를
 *     새 Error의 .cause에 그대로 담아서 끝까지 들고 올라간다.
 *   - dtype은 q4 → q8 → fp32 순서로 자동 재시도한다 (모델 저장소에 q4가
 *     없을 수도 있어서).
 *   - Safari/iOS는 WebGPU를 시도하지 않고 WASM을 강제 사용한다.
 *
 * 진단 전용(테스트 버튼)으로 AutoTokenizer/AutoModelForCausalLM을 따로
 * 불러와서 "토크나이저만" / "모델 파일만" 독립적으로 성공/실패를 확인할 수 있다.
 * 실제 대화 생성 경로는 검증된 pipeline() API를 그대로 사용한다(안정성 우선).
 */

const HolmLocalAI = (() => {
  const TRANSFORMERS_CDN = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.0";
  const CDN_IMPORT_TIMEOUT_MS = 20000;
  const DTYPE_FALLBACK_CHAIN = ["q4", "q8", "fp32"];

  let statusListeners = [];
  let stageLog = [];
  let fileLog = [];
  let lastError = null;
  let cachedEnv = null;
  let pipelineInstance = null;
  let loadedInfo = { modelId: null, device: null, dtype: null, downloadedBytes: 0 };
  let loadPromise = null;

  // ===== 상태 이벤트 =====
  function onStatus(fn) { statusListeners.push(fn); }
  function _emit(s) { statusListeners.forEach((fn) => { try { fn(s); } catch (e) { /* noop */ } }); }

  function _pushStage(stage, status, detail) {
    const entry = { stage, status, at: new Date().toISOString(), detail: detail || null };
    stageLog.push(entry);
    _emit({ phase: "stage", ...entry });
    return entry;
  }

  // ===== 오류를 절대 잃어버리지 않기 위한 헬퍼 =====
  function _fullDetail(e, extra = {}) {
    const cause = e && e.cause ? e.cause : null;
    return {
      name: (e && e.name) || "Error",
      message: (e && e.message) || String(e),
      stack: e && e.stack ? String(e.stack).slice(0, 500) : null,
      cause: cause ? { name: cause.name, message: cause.message } : null,
      ...extra,
    };
  }

  function _wrapError(message, stage, cause) {
    const err = new Error(message);
    err.cause = cause;
    err._stage = stage;
    return err;
  }

  // ===== 환경 진단 (기존과 동일 로직 유지) =====
  function _detectBrowser() {
    const ua = navigator.userAgent || "";
    const isIOS = /iP(hone|od|ad)/.test(navigator.platform || "") ||
      (/Mac/.test(navigator.platform || "") && navigator.maxTouchPoints > 1);
    const isSafari = /^((?!chrome|android|crios|fxios).)*safari/i.test(ua);
    return { isIOS, isSafari, ua };
  }

  async function _checkWasm() {
    try {
      if (typeof WebAssembly !== "object") return false;
      const bytes = new Uint8Array([0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00]);
      await WebAssembly.instantiate(bytes);
      return true;
    } catch (e) {
      return false;
    }
  }

  async function _checkWebGPU() {
    try {
      if (!navigator.gpu) return false;
      const withTimeout = Promise.race([
        navigator.gpu.requestAdapter(),
        new Promise((resolve) => setTimeout(() => resolve(null), 3000)),
      ]);
      const adapter = await withTimeout;
      return !!adapter;
    } catch (e) {
      return false;
    }
  }

  async function diagnoseEnvironment(forceRefresh = false) {
    if (cachedEnv && !forceRefresh) return cachedEnv;
    const { isIOS, isSafari, ua } = _detectBrowser();
    const [wasmOk, webgpuOk] = await Promise.all([_checkWasm(), _checkWebGPU()]);
    cachedEnv = {
      browser: isSafari ? "Safari" : ua.includes("Chrome") ? "Chrome" : ua.includes("Firefox") ? "Firefox" : "Other",
      platform: isIOS ? "iPhone/iPad" : (navigator.platform || "Unknown"),
      isIOS,
      isSafari,
      webgpu: webgpuOk ? "available" : "unavailable",
      wasm: wasmOk ? "available" : "unavailable",
      worker: typeof Worker !== "undefined" ? "available" : "unavailable",
      indexedDB: "indexedDB" in window ? "available" : "unavailable",
    };
    return cachedEnv;
  }

  function _chooseDevice(env) {
    if (env.isSafari || env.isIOS) return "wasm";
    if (env.webgpu === "available") return "webgpu";
    return "wasm";
  }

  function _withTimeout(promise, ms, label) {
    return Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(_wrapError(`시간 초과: ${label}`, "timeout", null)), ms)),
    ]);
  }

  // ===== fetch 가로채기: 실제로 어떤 파일이 성공/실패했는지 그대로 기록 =====
  function _installFetchTracker() {
    const original = window.fetch;
    window.fetch = async function (input, init) {
      const url = typeof input === "string" ? input : input?.url || String(input);
      const isRelevant = /huggingface\.co|jsdelivr\.net|hf\.co/i.test(url);
      let entry = null;
      if (isRelevant) {
        entry = { url, fileName: url.split("/").pop().split("?")[0], status: "start", startedAt: Date.now() };
        fileLog.push(entry);
        _emit({ phase: "file", ...entry });
      }
      try {
        const res = await original(input, init);
        if (entry) {
          entry.status = res.ok ? "success" : "failed";
          entry.httpStatus = res.status;
          const len = res.headers.get("content-length");
          entry.bytes = len ? parseInt(len, 10) : null;
          entry.endedAt = Date.now();
          _emit({ phase: "file", ...entry });
        }
        return res;
      } catch (e) {
        if (entry) {
          entry.status = "failed";
          entry.error = e.message;
          entry.endedAt = Date.now();
          _emit({ phase: "file", ...entry });
        }
        throw e;
      }
    };
    return () => { window.fetch = original; };
  }

  async function _importTransformers() {
    _pushStage("cdn_import", "start");
    try {
      const mod = await _withTimeout(import(TRANSFORMERS_CDN), CDN_IMPORT_TIMEOUT_MS, "cdn_import");
      _pushStage("cdn_import", "success");
      return mod;
    } catch (e) {
      _pushStage("cdn_import", "failed", _fullDetail(e));
      throw _wrapError("Transformers.js를 불러오지 못했어요 (CDN import 실패)", "cdn_import", e);
    }
  }

  // ===== 실제 로딩 (pipeline API 사용 — 검증된 경로) =====
  async function _ensureLoadedInternal(modelId) {
    stageLog = [];
    fileLog = [];
    const restoreFetch = _installFetchTracker();

    try {
      const env = await diagnoseEnvironment(true);
      const device = _chooseDevice(env);
      loadedInfo.device = device;
      _pushStage("env-check", "success", env);
      _emit({ phase: "env-check", env, device });

      if (env.wasm === "unavailable" && device === "wasm") {
        throw _wrapError("이 브라우저는 WASM을 지원하지 않아요.", "wasm_check", null);
      }

      const { pipeline } = await _importTransformers();

      _pushStage("pipeline_create", "start");
      _emit({ phase: "start", device, modelId });

      let lastAttemptError = null;
      for (const dtype of DTYPE_FALLBACK_CHAIN) {
        _pushStage(`model_download[${dtype}]`, "start");
        try {
          const generator = await pipeline("text-generation", modelId, {
            dtype,
            device,
            progress_callback: (p) => {
              if (p.status === "progress" && p.total) {
                loadedInfo.downloadedBytes = Math.max(loadedInfo.downloadedBytes, p.total);
                const pct = Math.round((p.loaded / p.total) * 100);
                _emit({ phase: "downloading", pct, file: p.file, dtype, device, totalBytes: p.total });
              }
            },
          });
          _pushStage(`model_download[${dtype}]`, "success");
          _pushStage("pipeline_create", "success");

          pipelineInstance = generator;
          loadedInfo.modelId = modelId;
          loadedInfo.dtype = dtype;
          lastError = null;
          _pushStage("ready", "success");
          _emit({ phase: "ready", device, dtype });
          return generator;
        } catch (e) {
          _pushStage(`model_download[${dtype}]`, "failed", _fullDetail(e));
          console.warn(`[HolmLocalAI] dtype=${dtype} 실패, 다음 옵션 시도:`, e);
          lastAttemptError = e;
        }
      }
      _pushStage("pipeline_create", "failed", _fullDetail(lastAttemptError));
      throw _wrapError("모델 파일을 불러오지 못했어요 (모든 dtype 옵션 실패)", "model_download", lastAttemptError);
    } catch (e) {
      const stage = e._stage || "unknown";
      const rootCause = e.cause || e;
      const detail = _fullDetail(rootCause, { stage, backend: loadedInfo.device, modelId, topMessage: e.message });
      lastError = detail;

      console.error("[HolmLocalAI] === 로딩 실패 상세 ===", {
        stage,
        error: detail,
        stageLog: [...stageLog],
        fileLog: [...fileLog],
        env: cachedEnv,
      });

      _emit({ phase: "error", ...detail, stageLog: [...stageLog], fileLog: [...fileLog] });
      const finalErr = _wrapError(e.message, stage, rootCause);
      throw finalErr;
    } finally {
      restoreFetch();
    }
  }

  function ensureLoaded(modelId) {
    if (loadPromise && loadedInfo.modelId === modelId) return loadPromise;
    loadPromise = _ensureLoadedInternal(modelId).catch((err) => {
      loadPromise = null;
      throw err;
    });
    return loadPromise;
  }

  function isReady(modelId) {
    return loadedInfo.modelId === modelId && !!pipelineInstance;
  }

  function getLastError() { return lastError; }
  function getLoadedInfo() { return { ...loadedInfo }; }
  function getDiagnosticsReport() {
    return { env: cachedEnv, stages: [...stageLog], files: [...fileLog], lastError, loadedInfo: { ...loadedInfo } };
  }

  async function generate({ system, history, userInput, modelId }) {
    _pushStage("generate", "start");
    try {
      const generator = await ensureLoaded(modelId);

      const messages = [{ role: "system", content: system }];
      (history || []).slice(-10).forEach((m) => {
        messages.push({ role: m.role === "user" ? "user" : "assistant", content: m.text });
      });
      messages.push({ role: "user", content: userInput });

      const output = await _withTimeout(
        generator(messages, { max_new_tokens: 300, temperature: 0.7, top_k: 40, do_sample: true }),
        60000,
        "generate"
      );
      _pushStage("generate", "success");
      const last = output[0].generated_text.at(-1);
      return (last && last.content) || "";
    } catch (e) {
      _pushStage("generate", "failed", _fullDetail(e));
      const rootCause = e.cause || e;
      const detail = _fullDetail(rootCause, { stage: "generate" });
      lastError = detail;
      console.error("[HolmLocalAI] 생성 실패 상세:", detail);
      throw _wrapError(e.message || "생성 중 오류가 발생했어요.", "generate", rootCause);
    }
  }

  // ===== 개별 진단 테스트 버튼 (실제 API를 직접, 독립적으로 호출) =====
  async function testCDN() {
    const t0 = performance.now();
    try {
      await _withTimeout(import(TRANSFORMERS_CDN), CDN_IMPORT_TIMEOUT_MS, "cdn_test");
      return { ok: true, ms: Math.round(performance.now() - t0) };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testWasm() {
    const ok = await _checkWasm();
    return { ok };
  }

  async function testHFConnectivity(modelId) {
    const url = `https://huggingface.co/${modelId}/resolve/main/config.json`;
    const t0 = performance.now();
    try {
      const res = await fetch(url);
      const text = await res.text();
      return { ok: res.ok, httpStatus: res.status, ms: Math.round(performance.now() - t0), bytes: text.length };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testTokenizer(modelId) {
    fileLog = [];
    const restore = _installFetchTracker();
    try {
      const { AutoTokenizer } = await import(TRANSFORMERS_CDN);
      await AutoTokenizer.from_pretrained(modelId);
      return { ok: true, files: fileLog.filter((f) => /tokenizer/i.test(f.fileName)) };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e), files: [...fileLog] };
    } finally {
      restore();
    }
  }

  async function testModelFile(modelId, device) {
    fileLog = [];
    const restore = _installFetchTracker();
    try {
      const { AutoModelForCausalLM } = await import(TRANSFORMERS_CDN);
      let lastErr = null;
      for (const dtype of DTYPE_FALLBACK_CHAIN) {
        try {
          await AutoModelForCausalLM.from_pretrained(modelId, { dtype, device: device || "wasm" });
          return { ok: true, dtype, files: [...fileLog] };
        } catch (e) {
          lastErr = e;
        }
      }
      return { ok: false, detail: _fullDetail(lastErr), files: [...fileLog] };
    } finally {
      restore();
    }
  }

  async function testPipeline(modelId) {
    try {
      await ensureLoaded(modelId);
      return { ok: true };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e.cause || e) };
    }
  }

  async function testGenerate(modelId) {
    try {
      const text = await generate({ system: "너는 테스트용 봇이다. 짧게 답해라.", history: [], userInput: "안녕", modelId });
      return { ok: !!text, text };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e.cause || e) };
    }
  }

  return {
    generate,
    ensureLoaded,
    isReady,
    onStatus,
    diagnoseEnvironment,
    getLastError,
    getLoadedInfo,
    getDiagnosticsReport,
    testCDN,
    testWasm,
    testHFConnectivity,
    testTokenizer,
    testModelFile,
    testPipeline,
    testGenerate,
  };
})();
