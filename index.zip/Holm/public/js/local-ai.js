/**
 * local-ai.js
 * Holm에 내장되는 오픈소스 소형 언어모델 (Qwen2.5-Instruct, transformers.js).
 *
 * v3.4: 결정적인 단서 — "채팅도 무반응, 설정의 진단 버튼도 무반응"은 코드가
 * 죽은 게 아니라 AI 연산이 메인 스레드를 동기적으로 막고 있다는 뜻이었다.
 * WASM 추론은 기본적으로 호출한 스레드를 그대로 점유하는데, 지금까지는
 * 그 계산을 메인 스레드(화면을 그리는 스레드)에서 바로 돌리고 있었다.
 * 그래서 iPhone처럼 느린 기기에서 계산이 오래 걸리면 버튼 클릭도, 진단도,
 * 애니메이션도 전부 같이 얼어붙는다 — 타임아웃(setTimeout)조차 발화되지
 * 않을 수 있다 (메인 스레드가 막혀 있으면 타이머 콜백도 못 돈다).
 *
 * 수정: 모델 로딩과 추론을 전부 Web Worker(별도 스레드)로 옮긴다.
 *   - 메인 스레드는 항상 자유로워서 버튼/애니메이션/설정 화면이 계속 반응한다.
 *   - 계산이 아무리 오래 걸려도 최소한 "아직 계산 중"이라는 걸 화면에서
 *     계속 보여줄 수 있다.
 *   - Worker는 <script> 태그로 별도 파일을 두지 않고 Blob URL로 만들어서,
 *     단일 HTML 파일(holm-standalone.html) 안에서도 그대로 동작한다.
 */

const HolmLocalAI = (() => {
  const TRANSFORMERS_CDN = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.0";
  const CDN_IMPORT_TIMEOUT_MS = 20000;
  const GENERATE_TIMEOUT_MS = 120000; // 워커라 메인 스레드는 안 막히지만, 그래도 무한 대기는 방지
  const DTYPE_FALLBACK_CHAIN = ["q4", "q8", "fp32"];

  let statusListeners = [];
  let stageLog = [];
  let fileLog = [];
  let lastError = null;
  let cachedEnv = null;
  let loadedInfo = { modelId: null, device: null, dtype: null, downloadedBytes: 0 };
  let loadPromise = null;
  let loadCount = 0;
  let pageLoadedAt = Date.now();

  let worker = null;
  let pendingCalls = new Map(); // id -> {resolve, reject}
  let callIdSeq = 0;

  // ===== 상태 이벤트 =====
  function onStatus(fn) { statusListeners.push(fn); }
  function _emit(s) { statusListeners.forEach((fn) => { try { fn(s); } catch (e) { /* noop */ } }); }

  function _pushStage(stage, status, detail) {
    const entry = { stage, status, at: new Date().toISOString(), detail: detail || null };
    stageLog.push(entry);
    _emit({ phase: "stage", ...entry });
    return entry;
  }

  function resetLogs() { stageLog = []; fileLog = []; }

  function _fullDetail(e, extra = {}) {
    if (!e) return { name: "Error", message: "알 수 없는 오류", stack: null, cause: null, ...extra };
    const cause = e.cause || null;
    return {
      name: e.name || "Error",
      message: e.message || String(e),
      stack: e.stack ? String(e.stack).slice(0, 800) : null,
      cause: cause ? { name: cause.name || "Error", message: cause.message || String(cause) } : null,
      ...extra,
    };
  }

  function _wrapError(message, stage, cause, name) {
    const err = new Error(message);
    if (name) err.name = name;
    err.cause = cause;
    err._stage = stage;
    return err;
  }

  // ===== 환경 진단 (메인 스레드에서 수행 — 가볍고 빠름) =====
  function _detectBrowser() {
    const ua = navigator.userAgent || "";
    const isIOS = /iP(hone|od|ad)/.test(navigator.platform || "") ||
      (/Mac/.test(navigator.platform || "") && navigator.maxTouchPoints > 1);
    const isSafari = /^((?!chrome|android|crios|fxios).)*safari/i.test(ua);
    return { isIOS, isSafari, ua };
  }

  async function _checkWasm() {
    try {
      if (typeof WebAssembly !== "object") return false;
      const bytes = new Uint8Array([0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00]);
      await WebAssembly.instantiate(bytes);
      return true;
    } catch (e) { return false; }
  }

  async function _checkWebGPU() {
    try {
      if (!navigator.gpu) return false;
      const withTimeout = Promise.race([
        navigator.gpu.requestAdapter(),
        new Promise((resolve) => setTimeout(() => resolve(null), 3000)),
      ]);
      return !!(await withTimeout);
    } catch (e) { return false; }
  }

  function _navigationInfo() {
    try {
      const nav = performance.getEntriesByType("navigation")[0];
      return {
        type: nav ? nav.type : "unknown",
        secondsSincePageLoad: Math.round((Date.now() - pageLoadedAt) / 1000),
        crossOriginIsolated: typeof crossOriginIsolated !== "undefined" ? crossOriginIsolated : "unknown",
      };
    } catch (e) {
      return { type: "unknown", secondsSincePageLoad: null, crossOriginIsolated: "unknown" };
    }
  }

  async function diagnoseEnvironment(forceRefresh = false) {
    if (cachedEnv && !forceRefresh) return cachedEnv;
    const { isIOS, isSafari, ua } = _detectBrowser();
    const [wasmOk, webgpuOk] = await Promise.all([_checkWasm(), _checkWebGPU()]);
    cachedEnv = {
      browser: isSafari ? "Safari" : ua.includes("Chrome") ? "Chrome" : ua.includes("Firefox") ? "Firefox" : "Other",
      platform: isIOS ? "iPhone/iPad" : (navigator.platform || "Unknown"),
      isIOS, isSafari,
      webgpu: webgpuOk ? "available" : "unavailable",
      wasm: wasmOk ? "available" : "unavailable",
      worker: typeof Worker !== "undefined" ? "available" : "unavailable",
      indexedDB: "indexedDB" in window ? "available" : "unavailable",
      navigation: _navigationInfo(),
    };
    return cachedEnv;
  }

  function _chooseDevice(env) {
    if (env.isSafari || env.isIOS) return "wasm";
    if (env.webgpu === "available") return "webgpu";
    return "wasm";
  }

  function _withTimeout(promise, ms, label) {
    return Promise.race([
      promise,
      new Promise((_, reject) =>
        setTimeout(() => reject(_wrapError(`${label} 처리 시간이 ${ms}ms를 넘어서 중단했어요.`, "timeout", null, "HolmTimeoutError")), ms)
      ),
    ]);
  }

  // ===== Web Worker 소스 (Blob URL로 생성 — 별도 파일 없이 단일 HTML에서도 동작) =====
  const WORKER_SOURCE = `
    let pipeline, AutoTokenizer, AutoModelForCausalLM, xenovaEnv;
    let pipelineInstance = null;
    let currentModelId = null;
    let currentDtype = null;
    let fileLog = [];

    function installFetchTracker() {
      const original = self.fetch;
      self.fetch = async function (input, init) {
        const url = typeof input === "string" ? input : (input && input.url) || String(input);
        const isRelevant = /huggingface\\.co|jsdelivr\\.net|hf\\.co/i.test(url);
        let entry = null;
        if (isRelevant) {
          entry = { url, fileName: url.split("/").pop().split("?")[0], status: "start", startedAt: Date.now() };
          fileLog.push(entry);
          self.postMessage({ kind: "event", event: { phase: "file", ...entry } });
        }
        try {
          const res = await original(input, init);
          if (entry) {
            entry.status = res.ok ? "success" : "failed";
            entry.httpStatus = res.status;
            const len = res.headers.get("content-length");
            entry.bytes = len ? parseInt(len, 10) : null;
            entry.endedAt = Date.now();
            self.postMessage({ kind: "event", event: { phase: "file", ...entry } });
          }
          return res;
        } catch (e) {
          if (entry) {
            entry.status = "failed";
            entry.error = e.message;
            entry.endedAt = Date.now();
            self.postMessage({ kind: "event", event: { phase: "file", ...entry } });
          }
          throw e;
        }
      };
      return () => { self.fetch = original; };
    }

    function fullDetail(e) {
      if (!e) return { name: "Error", message: "알 수 없는 오류", stack: null, cause: null };
      const cause = e.cause || null;
      return {
        name: e.name || "Error",
        message: e.message || String(e),
        stack: e.stack ? String(e.stack).slice(0, 800) : null,
        cause: cause ? { name: cause.name || "Error", message: cause.message || String(cause) } : null,
      };
    }

    async function importTransformers() {
      const mod = await import("${TRANSFORMERS_CDN}");
      pipeline = mod.pipeline;
      AutoTokenizer = mod.AutoTokenizer;
      AutoModelForCausalLM = mod.AutoModelForCausalLM;
      xenovaEnv = mod.env;
      return mod;
    }

    async function configureBackendForSafari(isSafariLike) {
      try {
        if (xenovaEnv && xenovaEnv.backends && xenovaEnv.backends.onnx && xenovaEnv.backends.onnx.wasm && isSafariLike) {
          xenovaEnv.backends.onnx.wasm.numThreads = 1;
          xenovaEnv.backends.onnx.wasm.proxy = false;
        }
      } catch (e) { /* 구조가 다르면 무시 */ }
    }

    async function ensureLoaded(modelId, device, dtypeChain, isSafariLike) {
      if (pipelineInstance && currentModelId === modelId) return { device, dtype: currentDtype };
      fileLog = [];
      const restore = installFetchTracker();
      try {
        self.postMessage({ kind: "event", event: { phase: "stage", stage: "cdn_import", status: "start" } });
        await importTransformers();
        self.postMessage({ kind: "event", event: { phase: "stage", stage: "cdn_import", status: "success" } });

        await configureBackendForSafari(isSafariLike);

        let lastErr = null;
        for (const dtype of dtypeChain) {
          self.postMessage({ kind: "event", event: { phase: "stage", stage: "model_download[" + dtype + "]", status: "start" } });
          try {
            const generator = await pipeline("text-generation", modelId, {
              dtype, device,
              progress_callback: (p) => {
                if (p.status === "progress" && p.total) {
                  const pct = Math.round((p.loaded / p.total) * 100);
                  self.postMessage({ kind: "event", event: { phase: "downloading", pct, file: p.file, dtype, device, totalBytes: p.total } });
                }
              },
            });
            self.postMessage({ kind: "event", event: { phase: "stage", stage: "model_download[" + dtype + "]", status: "success" } });
            pipelineInstance = generator;
            currentModelId = modelId;
            currentDtype = dtype;
            self.postMessage({ kind: "event", event: { phase: "ready", device, dtype } });
            return { device, dtype };
          } catch (e) {
            self.postMessage({ kind: "event", event: { phase: "stage", stage: "model_download[" + dtype + "]", status: "failed", detail: fullDetail(e) } });
            lastErr = e;
          }
        }
        const err = new Error("모델 파일을 불러오지 못했어요 (모든 dtype 옵션 실패)");
        err.cause = lastErr;
        err._stage = "model_download";
        throw err;
      } finally {
        restore();
      }
    }

    async function runGenerate(payload) {
      const { system, history, userInput, modelId, device, dtypeChain, isSafariLike, maxNewTokens } = payload;
      const restore = installFetchTracker();
      try {
        await ensureLoaded(modelId, device, dtypeChain, isSafariLike);
        const messages = [{ role: "system", content: system }];
        (history || []).slice(-10).forEach((m) => messages.push({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
        messages.push({ role: "user", content: userInput });

        self.postMessage({ kind: "event", event: { phase: "stage", stage: "generate", status: "start" } });

        // 토큰이 하나씩 나올 때마다 메인 스레드로 보내서 화면에 실시간 표시한다.
        // 이러면 "멈춘 것"과 "느린 것"을 사용자가 눈으로 구분할 수 있다.
        let streamed = "";
        let callbackFn = null;
        try {
          const mod = await import("${TRANSFORMERS_CDN}");
          if (mod.TextStreamer && pipelineInstance.tokenizer) {
            callbackFn = new mod.TextStreamer(pipelineInstance.tokenizer, {
              skip_prompt: true,
              skip_special_tokens: true,
              callback_function: (t) => {
                streamed += t;
                self.postMessage({ kind: "event", event: { phase: "token", text: streamed } });
              },
            });
          }
        } catch (e) { /* 스트리머를 못 만들면 그냥 일반 생성으로 진행 */ }

        const opts = { max_new_tokens: maxNewTokens || 96, temperature: 0.7, top_k: 40, do_sample: true };
        if (callbackFn) opts.streamer = callbackFn;

        const output = await pipelineInstance(messages, opts);
        self.postMessage({ kind: "event", event: { phase: "stage", stage: "generate", status: "success" } });
        const last = output[0].generated_text.at(-1);
        return (last && last.content) || streamed || "";
      } finally {
        restore();
      }
    }

    self.onmessage = async (e) => {
      const { id, type, payload } = e.data;
      try {
        let result;
        if (type === "ping") {
          result = "pong";
        } else if (type === "ensureLoaded") {
          result = await ensureLoaded(payload.modelId, payload.device, payload.dtypeChain, payload.isSafariLike);
        } else if (type === "generate") {
          result = await runGenerate(payload);
        } else if (type === "testTokenizer") {
          fileLog = [];
          const restore = installFetchTracker();
          try {
            if (!AutoTokenizer) await importTransformers();
            await AutoTokenizer.from_pretrained(payload.modelId);
            result = { ok: true, files: fileLog.filter(f => /tokenizer/i.test(f.fileName)) };
          } finally { restore(); }
        } else if (type === "testModelFile") {
          fileLog = [];
          const restore = installFetchTracker();
          try {
            if (!AutoModelForCausalLM) await importTransformers();
            let lastErr = null, okDtype = null;
            for (const dtype of payload.dtypeChain) {
              try {
                await AutoModelForCausalLM.from_pretrained(payload.modelId, { dtype, device: payload.device || "wasm" });
                okDtype = dtype;
                break;
              } catch (e) { lastErr = e; }
            }
            result = okDtype ? { ok: true, dtype: okDtype, files: fileLog } : { ok: false, detail: fullDetail(lastErr), files: fileLog };
          } finally { restore(); }
        } else {
          throw new Error("알 수 없는 명령: " + type);
        }
        self.postMessage({ id, kind: "result", ok: true, result });
      } catch (err) {
        self.postMessage({ id, kind: "result", ok: false, error: fullDetail(err), stage: err._stage || null });
      }
    };
  `;

  function _getWorker() {
    if (worker) return worker;
    const blob = new Blob([WORKER_SOURCE], { type: "application/javascript" });
    const url = URL.createObjectURL(blob);
    worker = new Worker(url, { type: "module" });
    worker.onmessage = (e) => {
      const { id, kind } = e.data;
      if (kind === "event") {
        const ev = e.data.event;
        if (ev.phase === "stage") _pushStage(ev.stage, ev.status, ev.detail);
        if (ev.phase === "file") fileLog.push(ev);
        _emit(ev);
        return;
      }
      if (kind === "result") {
        const pending = pendingCalls.get(id);
        if (!pending) return;
        pendingCalls.delete(id);
        if (e.data.ok) pending.resolve(e.data.result);
        else pending.reject(_wrapError(e.data.error.message, e.data.stage || "worker", e.data.error, e.data.error.name));
      }
    };
    worker.onerror = (e) => {
      console.error("[HolmLocalAI] Worker 자체 오류:", e);
      pendingCalls.forEach(({ reject }) => reject(_wrapError("Worker 실행 중 오류: " + e.message, "worker_error", null, "WorkerError")));
      pendingCalls.clear();
    };
    return worker;
  }

  function _callWorker(type, payload, timeoutMs) {
    return new Promise((resolve, reject) => {
      const id = ++callIdSeq;
      pendingCalls.set(id, { resolve, reject });
      if (timeoutMs) {
        setTimeout(() => {
          if (pendingCalls.has(id)) {
            pendingCalls.delete(id);
            reject(_wrapError(`${type} 처리 시간이 ${timeoutMs}ms를 넘었어요.`, "timeout", null, "HolmTimeoutError"));
          }
        }, timeoutMs);
      }
      try {
        _getWorker().postMessage({ id, type, payload });
      } catch (e) {
        pendingCalls.delete(id);
        reject(_wrapError("Worker에 메시지를 보내지 못했어요: " + e.message, "worker_dispatch", e));
      }
    });
  }

  async function _ensureLoadedInternal(modelId) {
    resetLogs();
    loadCount++;
    try {
      const env = await diagnoseEnvironment(true);
      const device = _chooseDevice(env);
      loadedInfo.device = device;
      _pushStage("env-check", "success", env);
      _emit({ phase: "env-check", env, device });

      if (env.wasm === "unavailable" && device === "wasm") {
        throw _wrapError("이 브라우저는 WASM을 지원하지 않아요.", "wasm_check", null);
      }
      if (env.worker === "unavailable") {
        throw _wrapError("이 브라우저는 Web Worker를 지원하지 않아요.", "worker_unavailable", null);
      }

      const { device: usedDevice, dtype } = await _callWorker(
        "ensureLoaded",
        { modelId, device, dtypeChain: DTYPE_FALLBACK_CHAIN, isSafariLike: env.isSafari || env.isIOS },
        300000 // 5분 — 워커라 화면은 안 막히지만, 그래도 완전한 무한 대기는 막는다
      );

      loadedInfo.modelId = modelId;
      loadedInfo.dtype = dtype;
      loadedInfo.device = usedDevice;
      lastError = null;
      return { device: usedDevice, dtype };
    } catch (e) {
      const stage = e._stage || "unknown";
      const rootCause = e.cause || e;
      const detail = _fullDetail(rootCause, { stage, backend: loadedInfo.device, modelId });
      lastError = detail;
      console.error("[HolmLocalAI] === 로딩 실패 상세 ===", { stage, error: detail, stageLog: [...stageLog], fileLog: [...fileLog] });
      _emit({ phase: "error", ...detail, stageLog: [...stageLog], fileLog: [...fileLog] });
      throw _wrapError(e.message, stage, rootCause, rootCause?.name);
    }
  }

  function ensureLoaded(modelId) {
    if (loadPromise && loadedInfo.modelId === modelId) {
      _pushStage("cache", "success", { note: "이미 불러온 파이프라인을 재사용함" });
      return loadPromise;
    }
    if (loadCount > 0) {
      _pushStage("cache_miss", "failed", {
        note: "이전에 불러온 적이 있는데도 캐시가 비어있음 — 페이지가 리로드됐을 가능성",
        navigation: _navigationInfo(),
      });
    }
    loadPromise = _ensureLoadedInternal(modelId).catch((err) => { loadPromise = null; throw err; });
    return loadPromise;
  }

  function isReady(modelId) { return loadedInfo.modelId === modelId; }
  function getLastError() { return lastError; }
  function getLoadedInfo() { return { ...loadedInfo, loadCount }; }
  function getDiagnosticsReport() {
    return { env: cachedEnv, stages: [...stageLog], files: [...fileLog], lastError, loadedInfo: { ...loadedInfo, loadCount }, navigation: _navigationInfo() };
  }

  async function generate({ system, history, userInput, modelId }) {
    const wasAlreadyLoaded = loadPromise && loadedInfo.modelId === modelId;
    _pushStage("generate", "start", { fromCache: !!wasAlreadyLoaded });
    try {
      const env = await diagnoseEnvironment();
      const device = loadedInfo.device || _chooseDevice(env);
      const text = await _callWorker(
        "generate",
        { system, history, userInput, modelId, device, dtypeChain: DTYPE_FALLBACK_CHAIN, isSafariLike: env.isSafari || env.isIOS, maxNewTokens: 96 },
        GENERATE_TIMEOUT_MS
      );
      _pushStage("generate", "success");
      loadedInfo.modelId = modelId; // 워커 안에서 로딩까지 성공했다는 뜻
      lastError = null;
      return text;
    } catch (e) {
      _pushStage("generate", "failed", _fullDetail(e));
      const rootCause = e.cause || e;
      const detail = _fullDetail(rootCause, { stage: "generate", wasAlreadyLoaded: !!wasAlreadyLoaded });
      lastError = detail;
      console.error("[HolmLocalAI] === 생성 실패 상세 ===", { error: detail, wasAlreadyLoaded: !!wasAlreadyLoaded, stageLog: [...stageLog], fileLog: [...fileLog] });
      _emit({ phase: "error", ...detail, stageLog: [...stageLog], fileLog: [...fileLog] });
      throw _wrapError(e.message || "생성 중 오류가 발생했어요.", "generate", rootCause, rootCause?.name);
    }
  }

  // ===== 개별 진단 테스트 버튼 =====
  async function testCDN() {
    const t0 = performance.now();
    try {
      await _withTimeout(import(TRANSFORMERS_CDN), CDN_IMPORT_TIMEOUT_MS, "cdn_test");
      return { ok: true, ms: Math.round(performance.now() - t0) };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testWasm() {
    return { ok: await _checkWasm() };
  }

  async function testHFConnectivity(modelId) {
    const url = `https://huggingface.co/${modelId}/resolve/main/config.json`;
    const t0 = performance.now();
    try {
      const res = await fetch(url);
      const text = await res.text();
      return { ok: res.ok, httpStatus: res.status, ms: Math.round(performance.now() - t0), bytes: text.length };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testTokenizer(modelId) {
    try {
      const result = await _callWorker("testTokenizer", { modelId }, CDN_IMPORT_TIMEOUT_MS + 30000);
      return result;
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testModelFile(modelId) {
    try {
      const env = await diagnoseEnvironment();
      const device = _chooseDevice(env);
      const result = await _callWorker("testModelFile", { modelId, device, dtypeChain: DTYPE_FALLBACK_CHAIN }, 90000);
      return result;
    } catch (e) {
      return { ok: false, detail: _fullDetail(e) };
    }
  }

  async function testPipeline(modelId) {
    try {
      await ensureLoaded(modelId);
      return { ok: true };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e.cause || e) };
    }
  }

  async function testGenerate(modelId) {
    try {
      const text = await generate({ system: "너는 테스트용 봇이다. 아주 짧게 답해라.", history: [], userInput: "안녕", modelId });
      return { ok: !!text, text };
    } catch (e) {
      return { ok: false, detail: _fullDetail(e.cause || e) };
    }
  }

  return {
    generate, ensureLoaded, isReady, onStatus, diagnoseEnvironment, resetLogs,
    getLastError, getLoadedInfo, getDiagnosticsReport,
    testCDN, testWasm, testHFConnectivity, testTokenizer, testModelFile, testPipeline, testGenerate,
  };
})();
