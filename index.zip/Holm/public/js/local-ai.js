/**
 * local-ai.js
 * Holm에 내장되는 오픈소스 소형 언어모델 (Qwen2.5-Instruct, transformers.js).
 *
 * iPhone Safari 대응이 핵심이다:
 *   - Safari(특히 iOS)에서는 WebGPU를 절대 먼저 시도하지 않는다 (WASM 강제).
 *   - WebGPU 지원 여부는 navigator.gpu 존재만 보지 않고 requestAdapter()까지
 *     실제로 호출해서 확인한다 (존재해도 동작 안 하는 경우가 있어서).
 *   - dtype(q4)이 해당 모델에 없을 수도 있으므로 q4 → q8 → fp32 순으로
 *     자동 재시도한다 ("Load failed"의 흔한 원인 중 하나).
 *   - CDN import, 모델 다운로드, WASM 초기화, 메모리 부족을 서로 다른
 *     오류로 구분해서 사용자에게 보여주고, 개발자 콘솔에는 항상
 *     error.name/message/stack 일부 + 사용한 device/dtype/환경을 남긴다.
 *   - 이 모듈이 실패해도 Memory/Knowledge/Tools 등 다른 모듈은 영향받지 않는다
 *     (model-adapter.js/brain.js가 독립적으로 처리함).
 */

const HolmLocalAI = (() => {
  const TRANSFORMERS_CDN = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.0";
  const CDN_IMPORT_TIMEOUT_MS = 20000;
  const DTYPE_FALLBACK_CHAIN = ["q4", "q8", "fp32"];

  let pipelinePromise = null;
  let loadedModelId = null;
  let loadedDevice = null;
  let loadedDtype = null;
  let lastError = null;
  let statusListeners = [];
  let cachedEnv = null;

  // ===== 상태 이벤트 =====
  function onStatus(fn) {
    statusListeners.push(fn);
  }
  function _emit(status) {
    statusListeners.forEach((fn) => {
      try { fn(status); } catch (e) { /* noop */ }
    });
  }

  // ===== 환경 진단 =====
  function _detectBrowser() {
    const ua = navigator.userAgent || "";
    const isIOS = /iP(hone|od|ad)/.test(navigator.platform || "") ||
      (/Mac/.test(navigator.platform || "") && navigator.maxTouchPoints > 1); // iPadOS가 Mac으로 위장하는 경우
    const isSafari = /^((?!chrome|android|crios|fxios).)*safari/i.test(ua);
    return { isIOS, isSafari, ua };
  }

  async function _checkWasm() {
    try {
      if (typeof WebAssembly !== "object") return false;
      // 아주 작은 유효 WASM 모듈을 실제로 인스턴스화해서 진짜 동작하는지 확인
      const bytes = new Uint8Array([0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00]);
      await WebAssembly.instantiate(bytes);
      return true;
    } catch (e) {
      return false;
    }
  }

  async function _checkWebGPU() {
    try {
      if (!navigator.gpu) return false;
      const withTimeout = Promise.race([
        navigator.gpu.requestAdapter(),
        new Promise((resolve) => setTimeout(() => resolve(null), 3000)),
      ]);
      const adapter = await withTimeout;
      return !!adapter;
    } catch (e) {
      return false;
    }
  }

  /** 브라우저 환경을 검사해서 진단 정보를 반환한다 (Settings UI에서 사용) */
  async function diagnoseEnvironment(forceRefresh = false) {
    if (cachedEnv && !forceRefresh) return cachedEnv;

    const { isIOS, isSafari, ua } = _detectBrowser();
    const [wasmOk, webgpuOk] = await Promise.all([_checkWasm(), _checkWebGPU()]);

    cachedEnv = {
      browser: isSafari ? "Safari" : ua.includes("Chrome") ? "Chrome" : ua.includes("Firefox") ? "Firefox" : "Other",
      isIOS,
      isSafari,
      webgpu: webgpuOk ? "available" : "unavailable",
      wasm: wasmOk ? "available" : "unavailable",
      worker: typeof Worker !== "undefined" ? "available" : "unavailable",
      indexedDB: "indexedDB" in window ? "available" : "unavailable",
    };
    return cachedEnv;
  }

  /** Safari(특히 iOS)에서는 WebGPU를 절대 먼저 쓰지 않는다 */
  function _chooseDevice(env) {
    if (env.isSafari || env.isIOS) return "wasm";
    if (env.webgpu === "available") return "webgpu";
    return "wasm";
  }

  // ===== 오류 분류 =====
  function _classifyError(e, stage) {
    const msg = (e && e.message) || String(e);
    const name = (e && e.name) || "Error";

    let code = "unknown_error";
    let userMessage = "원인을 정확히 알 수 없는 오류예요.";

    if (stage === "cdn_import") {
      code = "cdn_import_failed";
      userMessage = "AI 라이브러리(transformers.js)를 불러오지 못했어요. 네트워크 연결을 확인해주세요.";
    } else if (/wasm|webassembly/i.test(msg)) {
      code = "wasm_init_failed";
      userMessage = "WASM 실행 환경을 초기화하지 못했어요.";
    } else if (/rangeerror|allocat|memory/i.test(msg) || name === "RangeError") {
      code = "out_of_memory";
      userMessage = "브라우저 메모리 부족으로 모델을 실행하지 못했을 가능성이 있어요. 더 작은 모델(0.5B)로 시도해보세요.";
    } else if (/load failed|fetch|network|failed to fetch/i.test(msg)) {
      code = "model_download_failed";
      userMessage = "AI 모델 파일을 다운로드하지 못했어요. (네트워크 문제 또는 파일 접근 실패)";
    } else if (/timeout/i.test(msg)) {
      code = "timeout";
      userMessage = "시간이 너무 오래 걸려서 중단했어요. 네트워크 상태를 확인하고 다시 시도해주세요.";
    }

    const detail = {
      code,
      userMessage,
      name,
      message: msg,
      stack: e && e.stack ? String(e.stack).slice(0, 300) : null,
      stage,
    };
    return detail;
  }

  function _withTimeout(promise, ms, label) {
    return Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout: ${label}`)), ms)),
    ]);
  }

  async function _importTransformers() {
    try {
      return await _withTimeout(import(TRANSFORMERS_CDN), CDN_IMPORT_TIMEOUT_MS, "cdn_import");
    } catch (e) {
      throw Object.assign(new Error(e.message), { _stage: "cdn_import", _cause: e });
    }
  }

  async function _load(modelId) {
    const env = await diagnoseEnvironment();
    const device = _chooseDevice(env);

    _emit({ phase: "env-check", env, device });

    if (env.wasm === "unavailable" && device === "wasm") {
      const detail = { code: "wasm_init_failed", userMessage: "이 브라우저는 WASM을 지원하지 않아서 내장 AI를 실행할 수 없어요.", name: "EnvironmentError", message: "WASM unavailable", stage: "env-check" };
      lastError = detail;
      _emit({ phase: "error", ...detail, env, device });
      throw new Error(detail.userMessage);
    }

    const { pipeline, env: xenovaEnv } = await _importTransformers();

    // 동적 import로 다른 오리진(jsdelivr)에서 불러왔을 때 내부 WASM 경로 추론이
    // 꼬이는 경우가 있어, 명시적으로 같은 CDN 경로를 지정해준다 (Safari에서 흔한 원인).
    try {
      if (xenovaEnv?.backends?.onnx?.wasm) {
        xenovaEnv.backends.onnx.wasm.wasmPaths = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.0/dist/";
      }
    } catch (e) { /* 구조가 다르면 무시 */ }

    _emit({ phase: "start", device, modelId });

    let lastAttemptError = null;
    for (const dtype of DTYPE_FALLBACK_CHAIN) {
      try {
        _emit({ phase: "downloading", pct: 0, dtype, device });
        const generator = await pipeline("text-generation", modelId, {
          dtype,
          device,
          progress_callback: (p) => {
            if (p.status === "progress" && p.total) {
              const pct = Math.round((p.loaded / p.total) * 100);
              _emit({ phase: "downloading", pct, file: p.file, dtype, device });
            }
          },
        });
        loadedModelId = modelId;
        loadedDevice = device;
        loadedDtype = dtype;
        lastError = null;
        _emit({ phase: "ready", device, dtype });
        return generator;
      } catch (e) {
        console.warn(`[HolmLocalAI] dtype=${dtype} 로딩 실패, 다음 옵션으로 재시도:`, e);
        lastAttemptError = e;
      }
    }
    throw lastAttemptError || new Error("모든 dtype 옵션이 실패했어요.");
  }

  function ensureLoaded(modelId) {
    if (pipelinePromise && loadedModelId === modelId) return pipelinePromise;
    pipelinePromise = _load(modelId).catch((err) => {
      pipelinePromise = null;
      const stage = err._stage || "model_load";
      const detail = _classifyError(err._cause || err, stage);
      lastError = detail;

      console.error("[HolmLocalAI] 모델 로딩 실패", {
        ...detail,
        modelId,
        env: cachedEnv,
      });

      _emit({ phase: "error", ...detail, modelId, env: cachedEnv });
      throw new Error(detail.userMessage + ` (${detail.code})`);
    });
    return pipelinePromise;
  }

  function isReady(modelId) {
    return loadedModelId === modelId;
  }

  function getLastError() {
    return lastError;
  }

  function getLoadedInfo() {
    return { modelId: loadedModelId, device: loadedDevice, dtype: loadedDtype };
  }

  async function generate({ system, history, userInput, modelId }) {
    const generator = await ensureLoaded(modelId);

    const messages = [{ role: "system", content: system }];
    (history || []).slice(-10).forEach((m) => {
      messages.push({ role: m.role === "user" ? "user" : "assistant", content: m.text });
    });
    messages.push({ role: "user", content: userInput });

    _emit({ phase: "generating" });
    try {
      const output = await _withTimeout(
        generator(messages, { max_new_tokens: 300, temperature: 0.7, top_k: 40, do_sample: true }),
        60000,
        "generation"
      );
      const last = output[0].generated_text.at(-1);
      return (last && last.content) || "";
    } catch (e) {
      const detail = _classifyError(e, "generation");
      lastError = detail;
      console.error("[HolmLocalAI] 생성 실패", detail);
      throw new Error(detail.userMessage);
    }
  }

  return {
    generate,
    ensureLoaded,
    isReady,
    onStatus,
    diagnoseEnvironment,
    getLastError,
    getLoadedInfo,
  };
})();
