/**
 * tools-date.js
 * 오늘 날짜(요일 포함)를 알려주는 도구.
 */

const DateTool = {
  name: "date",
  description: "오늘 날짜를 알려줍니다.",
  execute() {
    const now = new Date();
    const days = ["일", "월", "화", "수", "목", "금", "토"];
    const y = now.getFullYear();
    const mo = now.getMonth() + 1;
    const d = now.getDate();
    const dow = days[now.getDay()];
    return `오늘은 ${y}년 ${mo}월 ${d}일 (${dow}요일)이에요.`;
  },
};
