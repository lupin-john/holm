/**
 * retrieval.js
 * 매번 모든 Memory/Knowledge를 AI에게 보내지 않고,
 * 현재 사용자 질문과 관련성 높은 것만 골라서 반환한다.
 *
 * 점수 계산은 rag.js와 같은 방식(키워드 겹침)을 재사용한다 —
 * 실제 임베딩 기반 검색이 아니라 그 전 단계의 근사치임을 명확히 한다.
 */

const HolmRetrieval = (() => {
  async function getContext(query, { memoryTopK = 4, knowledgeTopK = 3 } = {}) {
    const [memories, knowledge] = await Promise.all([
      HolmMemoryDB.search(query, memoryTopK),
      HolmKnowledgeDB.search(query, knowledgeTopK),
    ]);

    // 사용된 기억은 lastUsedAt을 갱신해서 "최근에 참고된 기억"을 추적할 수 있게 한다
    memories.forEach((m) => HolmMemoryDB.touchUsed(m.id));

    const ragChunks = HolmRAG.retrieve(query, 2);

    return { memories, knowledge, ragChunks };
  }

  return { getContext };
})();
