/**
 * model-adapter.js
 * Holm v3의 AI Router.
 *
 *   AI Router
 *    ├─ Local AI      (기본값, 항상 사용 가능, 비용 없음)
 *    ├─ Anthropic Adapter (BYOK, 선택)
 *    ├─ OpenAI Adapter    (BYOK, 선택, 구조만 — 브라우저 CORS 정책에 따라 막힐 수 있음)
 *    └─ Gemini Adapter    (BYOK, 선택, 구조만 — 위와 동일)
 *
 * Budget Mode가 "free_only"면 무조건 Local AI만 사용한다 (유료 API 절대 호출 안 함).
 * "allow_paid"이고 사용자가 api 모드 + 키를 등록했을 때만 외부 어댑터를 시도하고,
 * 실패하면 자동으로 Local AI로 폴백한다 (에러 하나로 전체가 멈추지 않게).
 */

const HolmModelAdapter = (() => {
  const ANTHROPIC_VERSION = "2023-06-01";

  // ===== 인터페이스: generateReply({system, history, userInput, image}) => Promise<string> =====

  const LocalAIAdapter = {
    name: "local-ai",
    async generateReply({ system, history, userInput }) {
      const modelId = HolmSettings.getLocalModel();
      const text = await HolmLocalAI.generate({ system, history, userInput, modelId });
      return text || "(모델이 빈 답변을 줬어요. 다시 한 번 물어봐 주세요.)";
    },
  };

  const AnthropicDirectAdapter = {
    name: "anthropic-direct",
    async generateReply({ system, history, userInput, image }) {
      const apiKey = HolmSettings.getApiKey();
      const model = HolmSettings.getModel();
      const messages = _historyToMessages(history);

      const contentBlocks = [];
      if (image) {
        contentBlocks.push({ type: "image", source: { type: "base64", media_type: image.mediaType, data: image.base64 } });
      }
      contentBlocks.push({ type: "text", text: userInput });
      messages.push({ role: "user", content: contentBlocks });

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": ANTHROPIC_VERSION,
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({ model, max_tokens: 1024, system, messages }),
      });

      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        const msg = errBody?.error?.message || `HTTP ${res.status}`;
        if (res.status === 401) throw new Error("Anthropic API 키가 올바르지 않아요.");
        if (res.status === 429) throw new Error("요청이 너무 많아요. 잠시 후 다시 시도해주세요.");
        throw new Error("Anthropic 응답 오류: " + msg);
      }
      const data = await res.json();
      return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n") || "(빈 응답)";
    },
  };

  const OpenAIAdapter = {
    name: "openai",
    async generateReply({ system, history, userInput }) {
      const apiKey = HolmSettings.getApiKey();
      const messages = [{ role: "system", content: system }, ..._historyToMessages(history, "openai"), { role: "user", content: userInput }];

      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: "Bearer " + apiKey },
        body: JSON.stringify({ model: "gpt-4o-mini", messages }),
      });

      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        throw new Error("OpenAI 응답 오류: " + (errBody?.error?.message || `HTTP ${res.status}`));
      }
      const data = await res.json();
      return data.choices?.[0]?.message?.content || "(빈 응답)";
    },
  };

  const GeminiAdapter = {
    name: "gemini",
    async generateReply({ system, history, userInput }) {
      const apiKey = HolmSettings.getApiKey();
      // 간단화된 버전: 시스템 + 이전 대화 + 현재 입력을 하나의 텍스트로 합쳐서 보낸다.
      const historyText = (history || []).slice(-10).map((m) => `${m.role === "user" ? "사용자" : "Holm"}: ${m.text}`).join("\n");
      const combined = [system, historyText, `사용자: ${userInput}`].filter(Boolean).join("\n\n");

      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ contents: [{ parts: [{ text: combined }] }] }),
        }
      );

      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        throw new Error("Gemini 응답 오류: " + (errBody?.error?.message || `HTTP ${res.status}`));
      }
      const data = await res.json();
      return data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "(빈 응답)";
    },
  };

  const EXTERNAL_ADAPTERS = { anthropic: AnthropicDirectAdapter, openai: OpenAIAdapter, gemini: GeminiAdapter };

  function _historyToMessages(history) {
    return (history || []).slice(-20).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
  }

  /** 지금 설정 기준으로 시도해야 할 어댑터 목록 (우선순위 순) */
  function _resolveChain() {
    if (HolmSettings.getBudgetMode() === "free_only") return [LocalAIAdapter];
    if (HolmSettings.isApiMode()) {
      const external = EXTERNAL_ADAPTERS[HolmSettings.getProvider()] || AnthropicDirectAdapter;
      return [external, LocalAIAdapter]; // 외부 실패 시 Local로 자동 폴백
    }
    return [LocalAIAdapter];
  }

  async function generateReply(payload) {
    const chain = _resolveChain();
    let lastError = null;

    for (const adapter of chain) {
      try {
        return await adapter.generateReply(payload);
      } catch (e) {
        console.warn(`[HolmModelAdapter] ${adapter.name} 실패:`, e.message, e.cause || "");
        lastError = e;
      }
    }
    // lastError는 local-ai.js/AnthropicDirectAdapter 등이 이미 사람이 읽을 수 있게
    // 다듬은 메시지이므로, 여기서 또 뭉뚱그리지 않고 그대로 올려보낸다.
    const finalError = new Error(lastError?.message || "사용 가능한 AI가 없어요.");
    finalError.cause = lastError;
    throw finalError;
  }

  function getAdapterName() {
    return _resolveChain()[0].name;
  }

  return { generateReply, getAdapterName, LocalAIAdapter, AnthropicDirectAdapter, OpenAIAdapter, GeminiAdapter };
})();
