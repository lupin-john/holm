/**
 * text-sim.js
 * 아주 단순한 단어-겹침 기반 유사도 계산 유틸.
 * Memory 중복 검사와 Context Retrieval(관련도 점수)에서 공용으로 사용한다.
 * 실제 임베딩이 아니라 Jaccard 유사도 수준의 근사치임을 명확히 한다.
 */

const HolmTextSim = (() => {
  function tokenize(text) {
    return (text || "")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .split(/\s+/)
      .filter((t) => t.length > 1);
  }

  // Jaccard 유사도: 교집합 / 합집합 (0~1)
  function jaccard(a, b) {
    const setA = new Set(tokenize(a));
    const setB = new Set(tokenize(b));
    if (!setA.size || !setB.size) return 0;
    let intersection = 0;
    setA.forEach((t) => {
      if (setB.has(t)) intersection++;
    });
    const union = setA.size + setB.size - intersection;
    return union === 0 ? 0 : intersection / union;
  }

  // 검색용: 쿼리 토큰이 텍스트에 얼마나 겹치는지 (개수 기반 점수)
  function overlapScore(query, text) {
    const q = tokenize(query);
    const t = new Set(tokenize(text));
    return q.filter((tok) => t.has(tok)).length;
  }

  return { tokenize, jaccard, overlapScore };
})();
