/**
 * tools-vision.js
 * 이미지 분석 도구.
 *
 * Holm에 기본 내장된 로컬 AI(Qwen2.5 텍스트 모델)는 이미지를 볼 수 없다.
 * 이미지 분석은 설정에서 "외부 API 키 연결"을 켜고 Anthropic API 키를
 * 등록했을 때만 가능하다 (선택 사항, 기본은 아님).
 */

const VisionTool = {
  name: "vision",
  description: "업로드된 이미지를 분석합니다. (외부 API 키 연결 시에만 가능)",

  isAvailable() {
    return HolmSettings.isApiMode();
  },

  unavailableMessage() {
    return (
      "기본 내장 AI는 텍스트 전용이라 이미지를 볼 수 없어요. " +
      "이미지를 분석하려면 ⚙ 설정에서 '외부 API 키 연결'을 켜고 Anthropic API 키를 등록해주세요."
    );
  },
};
