/**
 * reflection.js
 * Holm v3의 Reflection Engine.
 *
 * 설계 방식(중요): 비용을 늘리지 않기 위해, "기억 추출"을 별도의 AI 호출로
 * 만들지 않는다. 대신 brain.js가 AI에게 답변을 요청할 때 시스템 프롬프트에
 * "답변 뒤에 <memory>[...]</memory> 태그로 저장할 만한 정보를 JSON으로
 * 붙여라"라는 지시를 함께 보내고, 응답 하나에서 (1) 사용자에게 보여줄 답변과
 * (2) 기억 후보를 동시에 뽑아낸다. API를 두 번 부르지 않는다.
 *
 * AI가 태그를 안 붙이거나 JSON이 깨졌을 때를 대비해, 아주 단순한 규칙 기반
 * 추출(키워드 패턴)도 백업으로 함께 둔다.
 *
 * 최종 저장 여부는 다음 규칙을 따른다:
 *   - Learning Mode OFF → 아무것도 하지 않는다.
 *   - 기존 기억과 비슷한 내용(업데이트) → 조용히 병합.
 *   - 새 정보 + 중요도 낮음(<0.75) → 바로 저장.
 *   - 새 정보 + 중요도 높음(>=0.75) → Auto Save Memory가 켜져 있으면 바로 저장,
 *     꺼져 있으면 사용자 승인 대기 목록에 넣는다 ("이 내용을 기억할까요?").
 */

const HolmReflection = (() => {
  const APPROVAL_THRESHOLD = 0.75;

  const TRIVIAL_PATTERNS = [
    /^(안녕|하이|hi|hello|ㅎㅇ)[!.\s]*$/i,
    /^[ㅋㅎㅠㅜ]+$/,
    /^(응|어|네|넹|ㅇㅇ|오케이|ok|okay)[!.\s]*$/i,
    /^(고마워|고맙다|땡큐|thanks)[!.\s]*$/i,
    /^.{0,3}$/, // 3글자 이하 초단문
  ];

  function isTrivial(text) {
    const t = (text || "").trim();
    if (!t) return true;
    return TRIVIAL_PATTERNS.some((re) => re.test(t));
  }

  /** AI 시스템 프롬프트에 붙일 기억 추출 지시문 */
  function extractionInstruction() {
    return (
      "대화 맨 마지막에, 사용자에 대해 앞으로 기억해두면 좋을 새로운 정보가 있으면 " +
      "새 줄에 <memory>[...]</memory> 형태로 JSON 배열을 붙여라. " +
      '배열의 각 항목은 {"type":"user_preference|user_fact|project_fact|instruction|important_event","content":"...","importance":0.0-1.0} 형식이다. ' +
      "저장할 새 정보가 없으면 <memory>[]</memory>라고만 붙여라. " +
      "이 태그는 사용자에게 보이지 않으니 평소처럼 자연스럽게 답변한 다음에만 붙여라."
    );
  }

  /**
   * AI의 원본 응답에서 <memory>...</memory>를 분리한다.
   * @returns {{visibleText:string, candidates:Array}}
   */
  function parseModelReply(rawText) {
    const match = rawText.match(/<memory>([\s\S]*?)<\/memory>/i);
    if (!match) return { visibleText: rawText.trim(), candidates: [] };

    const visibleText = rawText.slice(0, match.index).trim();
    let candidates = [];
    try {
      const parsed = JSON.parse(match[1].trim());
      if (Array.isArray(parsed)) {
        candidates = parsed
          .filter((c) => c && c.content && c.type)
          .map((c) => ({
            type: c.type,
            content: String(c.content).slice(0, 300),
            importance: typeof c.importance === "number" ? Math.min(1, Math.max(0, c.importance)) : 0.6,
            confidence: 0.55, // AI 추론이므로 사용자 직접 발언보다 낮게
            source: "ai_reflection",
            tags: [],
          }));
      }
    } catch (e) {
      candidates = []; // JSON이 깨졌으면 그냥 무시 (백업 규칙 기반이 커버)
    }
    return { visibleText: visibleText || rawText.trim(), candidates };
  }

  /** AI가 아무것도 못 뽑았을 때 쓰는 아주 단순한 규칙 기반 백업 */
  function heuristicExtract(userInput) {
    const text = userInput.trim();
    if (isTrivial(text) || text.length < 6) return [];

    const rules = [
      { re: /(좋아해|선호해|좋아함)/, type: "user_preference", importance: 0.6 },
      { re: /(싫어해|싫음|안\s?좋아함)/, type: "user_preference", importance: 0.6 },
      { re: /(앞으로|이제부터).{0,20}(해줘|해주세요|답해줘)/, type: "instruction", importance: 0.8 },
      { re: /^나는\s|^내\s.+는\s|^제\s.+는\s/, type: "user_fact", importance: 0.55 },
      { re: /holm|Holm/i, type: "project_fact", importance: 0.6 },
    ];

    for (const rule of rules) {
      if (rule.re.test(text)) {
        return [
          {
            type: rule.type,
            content: text,
            importance: rule.importance,
            confidence: 0.75, // 사용자가 직접 말한 문장 그대로라 신뢰도는 준수
            source: "heuristic",
            tags: [],
          },
        ];
      }
    }
    return [];
  }

  /**
   * 후보들을 정책에 따라 저장하거나 승인 대기로 분류한다.
   * @returns {Promise<{saved:Array, pending:Array}>}
   */
  async function commitCandidates(candidates) {
    const saved = [];
    const pending = [];

    for (const cand of candidates) {
      const existing = await HolmMemoryDB.getAll();
      const dupExists = existing.some(
        (m) => m.type === cand.type && HolmTextSim.jaccard(m.content, cand.content) >= 0.55
      );

      if (dupExists || cand.importance < APPROVAL_THRESHOLD || HolmSettings.getAutoSaveMemory()) {
        const { record } = await HolmMemoryDB.addOrMerge(cand);
        saved.push(record);
      } else {
        pending.push(cand);
      }
    }
    return { saved, pending };
  }

  /**
   * brain.js에서 호출하는 메인 진입점.
   * @param {string} userInput
   * @param {string} rawAiReply AI의 원본 응답 (아직 <memory> 태그가 붙어있을 수 있음)
   * @returns {Promise<{visibleText:string, saved:Array, pending:Array}>}
   */
  async function reflect(userInput, rawAiReply) {
    if (!HolmSettings.getLearningMode()) {
      return { visibleText: rawAiReply, saved: [], pending: [] };
    }

    const { visibleText, candidates: aiCandidates } = parseModelReply(rawAiReply);
    const candidates = aiCandidates.length ? aiCandidates : heuristicExtract(userInput);

    if (!candidates.length) return { visibleText, saved: [], pending: [] };

    const { saved, pending } = await commitCandidates(candidates);
    return { visibleText, saved, pending };
  }

  return { reflect, isTrivial, extractionInstruction, parseModelReply, heuristicExtract };
})();
