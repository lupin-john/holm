/**
 * tools-files.js
 * 파일 업로드 처리.
 *   - 이미지 파일: base64로 변환해서 다음 채팅 메시지에 첨부 (Vision에서 사용)
 *   - 텍스트 파일(txt/md/csv/json): 내용을 읽어서 RAG 문서 저장소에 저장
 */

const FilesTool = {
  name: "files",
  description: "파일을 업로드합니다. 이미지는 AI에게 보여줄 수 있고, 텍스트 파일은 저장해서 질문에 참고합니다.",

  formatFileInfo(file) {
    const kb = (file.size / 1024).toFixed(1);
    return `📄 ${file.name} (${file.type || "알 수 없음"}, ${kb} KB)`;
  },

  isImage(file) {
    return file.type.startsWith("image/");
  },

  isText(file) {
    return (
      file.type.startsWith("text/") ||
      /\.(txt|md|csv|json)$/i.test(file.name)
    );
  },

  readAsBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        // dataURL 형식: "data:image/png;base64,AAAA..."
        const base64 = reader.result.split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  },

  readAsText(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  },
};
