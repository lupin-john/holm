/**
 * memory.js
 * ⚠️ v3부터는 memory-db.js(HolmMemoryDB, IndexedDB 기반)가 실제 장기 기억을 담당한다.
 * 이 파일은 v1/v2 호환을 위해 남겨둔 것으로, 지금은 어디에서도 호출되지 않는다.
 * (기존 파일을 삭제하지 않는다는 원칙에 따라 보존)
 */

const HolmMemory = (() => {
  const KEY = "holm_long_term_memory_v1";

  function _load() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error("[HolmMemory] 로드 실패:", e);
      return [];
    }
  }

  function _save(list) {
    localStorage.setItem(KEY, JSON.stringify(list));
    if (window.HolmHUD) {
      // 대략적인 사용량을 UI 표시용으로 계산 (실제 용량 %가 아님)
      const pct = Math.min(100, list.length * 4);
      HolmHUD.setMemoryUsagePercent(pct);
    }
  }

  function add(text) {
    const list = _load();
    const item = { id: Date.now().toString(36), text, createdAt: new Date().toISOString() };
    list.push(item);
    _save(list);
    return item;
  }

  function getAll() {
    return _load();
  }

  function remove(id) {
    const list = _load().filter((m) => m.id !== id);
    _save(list);
  }

  function clear() {
    _save([]);
  }

  return { add, getAll, remove, clear };
})();
