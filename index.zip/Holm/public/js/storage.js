/**
 * storage.js
 * 대화 기록(단기 기억) 저장소. 브라우저를 껐다 켜도 대화가 유지된다.
 *
 * v1: localStorage 기반.
 * v2 이후: 동일한 함수 시그니처(loadHistory/appendMessage/clearHistory)를
 *          유지한 채 IndexedDB 구현으로 교체 가능.
 */

const HolmStorage = (() => {
  const KEY = "holm_chat_history_v1";
  const MAX_MESSAGES = 200; // 너무 커지지 않도록 제한

  function loadHistory() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error("[HolmStorage] 대화 기록 로드 실패:", e);
      return [];
    }
  }

  function appendMessage(role, text) {
    const history = loadHistory();
    history.push({ role, text, at: new Date().toISOString() });
    while (history.length > MAX_MESSAGES) history.shift();
    localStorage.setItem(KEY, JSON.stringify(history));
    return history;
  }

  function clearHistory() {
    localStorage.removeItem(KEY);
  }

  return { loadHistory, appendMessage, clearHistory };
})();
