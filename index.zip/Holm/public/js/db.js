/**
 * db.js
 * Holm v3의 IndexedDB 래퍼. Memory/Knowledge/Conversation처럼
 * 커질 수 있는 데이터는 여기(IndexedDB)에 저장하고,
 * 작은 설정값은 계속 localStorage(settings.js)를 사용한다.
 *
 * 콜백 지옥을 피하기 위해 Promise로 감싼 아주 얇은 헬퍼만 제공한다.
 * 외부 라이브러리 없이 순수 브라우저 API(IndexedDB)만 사용한다.
 */

const HolmDB = (() => {
  const DB_NAME = "holm_db_v3";
  const DB_VERSION = 1;
  const STORES = ["memories", "knowledge", "conversations"];

  let dbPromise = null;

  function _open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        STORES.forEach((name) => {
          if (!db.objectStoreNames.contains(name)) {
            db.createObjectStore(name, { keyPath: "id" });
          }
        });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function put(storeName, record) {
    const db = await _open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      tx.objectStore(storeName).put(record);
      tx.oncomplete = () => resolve(record);
      tx.onerror = () => reject(tx.error);
    });
  }

  async function get(storeName, id) {
    const db = await _open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readonly");
      const req = tx.objectStore(storeName).get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async function getAll(storeName) {
    const db = await _open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readonly");
      const req = tx.objectStore(storeName).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function remove(storeName, id) {
    const db = await _open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      tx.objectStore(storeName).delete(id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  }

  async function clear(storeName) {
    const db = await _open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      tx.objectStore(storeName).clear();
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  }

  function isSupported() {
    return "indexedDB" in window;
  }

  return { put, get, getAll, remove, clear, isSupported };
})();
