/**
 * settings.js
 * Holm의 설정을 관리한다. (localStorage — 작은 값이라 IndexedDB 필요 없음)
 *
 * mode: "local" (기본값) — 브라우저 내장 오픈소스 모델 / "api" (선택) — 외부 API 키(BYOK)
 * budgetMode: "free_only" (기본값) — 유료 API를 절대 호출하지 않음 / "allow_paid" — api 모드+키가 있으면 허용
 * learningMode: true(기본) — 대화에서 기억 후보를 추출함 / false — 추출 안 함
 * autoSaveMemory: false(기본) — 중요도 높은 기억은 승인 후 저장 / true — 확인 없이 바로 저장
 */

const HolmSettings = (() => {
  const KEY = "holm_settings_v3";
  const DEFAULTS = {
    mode: "local",
    localModel: "HuggingFaceTB/SmolLM2-135M-Instruct",
    apiKey: "",
    provider: "anthropic",
    model: "claude-sonnet-5",
    budgetMode: "free_only",
    learningMode: true,
    autoSaveMemory: false,
  };

  function _load() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? { ...DEFAULTS, ...JSON.parse(raw) } : { ...DEFAULTS };
    } catch (e) {
      return { ...DEFAULTS };
    }
  }

  function getMode() { return _load().mode; }
  function getLocalModel() { return _load().localModel; }
  function getApiKey() { return _load().apiKey || ""; }
  function getProvider() { return _load().provider || "anthropic"; }
  function getModel() { return _load().model; }
  function hasApiKey() { return !!getApiKey(); }
  function getBudgetMode() { return _load().budgetMode; }
  function getLearningMode() { return !!_load().learningMode; }
  function getAutoSaveMemory() { return !!_load().autoSaveMemory; }

  // "api 모드 + 키가 있고 + 유료 호출이 허용됨"일 때만 외부 API를 실제로 쓴다
  function isApiMode() {
    const s = _load();
    return s.mode === "api" && !!s.apiKey && s.budgetMode !== "free_only";
  }

  function save(partial) {
    const current = _load();
    const next = { ...current, ...partial };
    if (next.apiKey !== undefined) next.apiKey = (next.apiKey || "").trim();
    localStorage.setItem(KEY, JSON.stringify(next));
    return next;
  }

  function clearApiKey() {
    save({ apiKey: "", mode: "local" });
  }

  return {
    getMode, getLocalModel, getApiKey, getProvider, getModel, hasApiKey,
    getBudgetMode, getLearningMode, getAutoSaveMemory,
    isApiMode, save, clearApiKey,
  };
})();
