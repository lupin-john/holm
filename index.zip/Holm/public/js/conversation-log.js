/**
 * conversation-log.js
 * 기존 storage.js(localStorage, 화면에 보여줄 최근 대화)와는 별도로,
 * 각 대화 턴을 메타데이터(관련 기억/지식 id, timestamp)와 함께
 * IndexedDB에 기록한다. 나중에 LoRA 학습 데이터를 만들 때 이 로그를 사용한다.
 *
 * 성능을 위해 일정 개수를 넘으면 오래된 항목을 요약 1건으로 압축한다
 * (AI를 새로 호출하지 않는 단순 추출 요약 — 비용 없음).
 */

const HolmConversationLog = (() => {
  const STORE = "conversations";
  const MAX_RAW_TURNS = 200; // 이 개수를 넘으면 오래된 것부터 압축

  function _id() {
    return "conv_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 7);
  }

  async function record({ userMessage, holmResponse, relatedMemoryIds = [], relatedKnowledgeIds = [] }) {
    const entry = {
      id: _id(),
      timestamp: new Date().toISOString(),
      userMessage,
      holmResponse,
      relatedMemoryIds,
      relatedKnowledgeIds,
      summarized: false,
    };
    await HolmDB.put(STORE, entry);
    await _compressIfNeeded();
    return entry;
  }

  async function getAll() {
    const all = await HolmDB.getAll(STORE);
    return all.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  }

  async function clearAll() {
    return HolmDB.clear(STORE);
  }

  // 오래된 원본 대화를 하나의 conversation_summary Memory로 압축하고 로그에서 지운다
  async function _compressIfNeeded() {
    const all = await getAll();
    const raw = all.filter((c) => !c.summarized);
    if (raw.length <= MAX_RAW_TURNS) return;

    const toCompress = raw.slice(0, raw.length - MAX_RAW_TURNS);
    const summaryText =
      "지난 대화 요약: " +
      toCompress
        .slice(0, 20) // 요약문 자체가 너무 길어지지 않도록 앞부분만 반영
        .map((c) => c.userMessage)
        .filter(Boolean)
        .join(" / ");

    await HolmMemoryDB.addOrMerge({
      type: "conversation_summary",
      content: summaryText.slice(0, 500),
      importance: 0.4,
      confidence: 0.5,
      source: "auto_compression",
      tags: ["summary"],
    });

    for (const c of toCompress) {
      await HolmDB.remove(STORE, c.id);
    }
  }

  /** LoRA 학습 준비용 JSONL 문자열 생성 (모델을 실제로 재학습하지는 않음) */
  async function exportTrainingJsonl() {
    const all = await getAll();
    const lines = all
      .filter((c) => c.userMessage && c.holmResponse)
      .map((c) =>
        JSON.stringify({
          messages: [
            { role: "user", content: c.userMessage },
            { role: "assistant", content: c.holmResponse },
          ],
        })
      );
    return lines.join("\n");
  }

  return { record, getAll, clearAll, exportTrainingJsonl };
})();
