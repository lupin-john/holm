/**
 * tools-search.js
 * 실제로 동작하는 검색 도구 (v4 조기 구현).
 * 별도 API 키가 필요 없는 위키백과 REST API를 사용한다.
 *   1) opensearch API로 제목 후보를 찾고 (origin=* 로 CORS 허용)
 *   2) REST summary API로 요약을 가져온다.
 *
 * 실시간 뉴스나 일반 웹 전체 검색은 아니고, 위키백과 기반 사실 검색이다.
 * 더 강력한 검색(구글/빙 등)을 붙이려면 여기 execute()만 교체하면 된다.
 */

const SearchTool = {
  name: "search",
  description: "위키백과에서 정보를 검색합니다.",

  async execute(query) {
    const q = query.trim();
    if (!q) return "검색할 내용을 입력해주세요.";

    try {
      const title = await _findBestTitle(q);
      if (!title) {
        return `"${q}"에 대한 위키백과 결과를 찾지 못했어요.`;
      }
      const summary = await _fetchSummary(title);
      if (!summary) {
        return `"${q}"에 대한 위키백과 결과를 찾지 못했어요.`;
      }
      return `📚 ${summary.title}\n\n${summary.extract}\n\n(출처: 위키백과 ${summary.url})`;
    } catch (e) {
      console.error("[SearchTool] 오류:", e);
      return "검색 중 오류가 발생했어요. 잠시 후 다시 시도해주세요.";
    }
  },
};

async function _findBestTitle(query) {
  const url =
    "https://ko.wikipedia.org/w/api.php?action=opensearch&format=json&origin=*&limit=1&search=" +
    encodeURIComponent(query);
  const res = await fetch(url);
  if (!res.ok) return null;
  const data = await res.json();
  // opensearch 응답 형식: [query, [titles], [descriptions], [urls]]
  return (data[1] && data[1][0]) || null;
}

async function _fetchSummary(title) {
  const url = "https://ko.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(title);
  const res = await fetch(url);
  if (!res.ok) return null;
  const data = await res.json();
  return {
    title: data.title,
    extract: data.extract,
    url: data.content_urls?.desktop?.page || `https://ko.wikipedia.org/wiki/${encodeURIComponent(title)}`,
  };
}
