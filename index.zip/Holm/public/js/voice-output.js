/**
 * voice-output.js
 * SpeechSynthesis API를 감싼 음성 출력 모듈.
 * 켜기/끄기 토글은 app.js에서 상태로 관리한다.
 */

const HolmVoiceOutput = (() => {
  let enabled = false;

  function isSupported() {
    return "speechSynthesis" in window;
  }

  function setEnabled(value) {
    enabled = value;
    if (!enabled) window.speechSynthesis.cancel();
  }

  function isEnabled() {
    return enabled;
  }

  function speak(text, { onStart, onEnd } = {}) {
    if (!enabled || !isSupported() || !text) {
      onEnd && onEnd();
      return;
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = "ko-KR";
    utter.rate = 1.0;
    utter.onstart = () => onStart && onStart();
    utter.onend = () => onEnd && onEnd();
    utter.onerror = () => onEnd && onEnd();
    window.speechSynthesis.speak(utter);
  }

  return { isSupported, setEnabled, isEnabled, speak };
})();
