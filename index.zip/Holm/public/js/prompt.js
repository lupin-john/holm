/**
 * prompt.js
 * AI에게 보낼 프롬프트를 조립한다.
 * Memory/Knowledge/RAG 컨텍스트를 넣고, Learning Mode가 켜져 있으면
 * Reflection 추출 지시문(<memory> 태그)도 시스템 프롬프트에 덧붙인다.
 */

const HolmPrompt = (() => {
  function buildSystemPrompt({ userName, holmName }) {
    const base = [
      `너는 "${holmName || "Holm"}"이라는 개인용 AI 비서다.`,
      userName ? `사용자의 이름은 "${userName}"이다.` : "",
      "한국어로 짧고 친절하게 답한다.",
    ]
      .filter(Boolean)
      .join(" ");

    if (HolmSettings.getLearningMode()) {
      return base + "\n\n" + HolmReflection.extractionInstruction();
    }
    return base;
  }

  function buildMessages({ systemPrompt, memories, knowledge, ragChunks, history, userInput }) {
    const memoryBlock =
      memories && memories.length
        ? "다음은 사용자에 대해 기억하고 있는 정보다 (참고만 하고, 관련 없으면 무시해도 된다):\n" +
          memories.map((m) => `- [${m.type}] ${m.content}`).join("\n")
        : "";

    const knowledgeBlock =
      knowledge && knowledge.length
        ? "다음은 관련된 지식이다:\n" + knowledge.map((k) => `- [${k.title}] ${k.content}`).join("\n")
        : "";

    const ragBlock =
      ragChunks && ragChunks.length
        ? "다음은 사용자가 업로드한 문서 중 관련 있어 보이는 내용이다:\n" +
          ragChunks.map((c) => `[${c.filename}] ${c.chunk}`).join("\n---\n")
        : "";

    return {
      system: [systemPrompt, memoryBlock, knowledgeBlock, ragBlock].filter(Boolean).join("\n\n"),
      history: history || [],
      userInput,
    };
  }

  return { buildSystemPrompt, buildMessages };
})();
