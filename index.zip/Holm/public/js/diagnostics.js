/**
 * diagnostics.js
 * 콘솔에서 `HolmDiagnostics.run()`을 호출하면 Holm의 각 모듈이
 * 서로 독립적으로 잘 동작하는지 순서대로 점검하고 결과를 표로 출력한다.
 * (요청사항 12번: 최소한의 self-test 기능)
 *
 * AI가 실패해도 Memory/Knowledge/Tools는 별개로 통과해야 정상이다.
 */

const HolmDiagnostics = (() => {
  async function run() {
    const results = [];
    const check = async (name, fn) => {
      try {
        const detail = await fn();
        results.push({ name, ok: true, detail: detail || "" });
      } catch (e) {
        results.push({ name, ok: false, detail: e.message });
      }
    };

    await check("환경 감지", async () => {
      const env = await HolmLocalAI.diagnoseEnvironment(true);
      return JSON.stringify(env);
    });

    await check("IndexedDB (Memory 저장소)", async () => {
      const test = await HolmMemoryDB.addOrMerge({
        type: "user_fact",
        content: "__diagnostics_test__",
        importance: 0.01,
        confidence: 0.5,
        source: "diagnostics",
      });
      await HolmMemoryDB.remove(test.record.id);
      return "쓰기/읽기/삭제 정상";
    });

    await check("Knowledge DB", async () => {
      const list = await HolmKnowledgeDB.getAll();
      return `${list.length}개 조회됨`;
    });

    await check("대화 로그(Conversation Log)", async () => {
      const list = await HolmConversationLog.getAll();
      return `${list.length}건 조회됨`;
    });

    await check("RAG 문서 저장소 (localStorage)", async () => {
      const docs = HolmRAG.listDocuments();
      return `${docs.length}개 문서`;
    });

    await check("Local AI 로딩", async () => {
      const modelId = HolmSettings.getLocalModel();
      await HolmLocalAI.ensureLoaded(modelId);
      const info = HolmLocalAI.getLoadedInfo();
      return `준비됨 (${info.device}/${info.dtype})`;
    });

    console.table(results.map((r) => ({ 모듈: r.name, 결과: r.ok ? "✅ 정상" : "❌ 실패", 상세: r.detail })));
    return results;
  }

  return { run };
})();
