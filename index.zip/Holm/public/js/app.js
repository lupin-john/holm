/**
 * app.js
 * 모든 모듈을 초기화하고 UI 이벤트를 연결하는 진입점.
 */

document.addEventListener("DOMContentLoaded", () => {
  // ===== 핵심 모듈 초기화 =====
  HolmCore.init(document.getElementById("holmCore"));
  HolmHUD.init();
  HolmChat.init();
  HolmMemoryUI.init();
  HolmState.set("IDLE");

  const chatInput = document.getElementById("chatInput");
  const sendBtn = document.getElementById("sendBtn");
  const micBtn = document.getElementById("micBtn");
  const speakToggleBtn = document.getElementById("speakToggleBtn");
  const fileBtn = document.getElementById("fileBtn");
  const fileInput = document.getElementById("fileInput");
  const filePreview = document.getElementById("filePreview");

  let pendingImage = null; // { base64, mediaType, fileName }

  // 입력창 높이 자동 조절
  chatInput.addEventListener("input", () => {
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + "px";
  });

  chatInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });

  sendBtn.addEventListener("click", handleSend);

  function handleSend() {
    const text = chatInput.value;
    if (!text.trim() && !pendingImage) return;
    chatInput.value = "";
    chatInput.style.height = "auto";
    const image = pendingImage;
    pendingImage = null;
    filePreview.textContent = "";
    HolmChat.sendUserMessage(text, image);
  }

  // ===== 음성 입력 =====
  micBtn.addEventListener("click", () => {
    if (!HolmVoiceInput.isSupported()) {
      HolmChat.renderFileNote("이 브라우저는 음성 인식을 지원하지 않아요.");
      return;
    }
    micBtn.classList.add("active");
    HolmState.set("LISTENING");

    HolmVoiceInput.start({
      onResult: (text) => {
        chatInput.value = text;
        handleSend();
      },
      onEnd: () => {
        micBtn.classList.remove("active");
        if (HolmState.get() === "LISTENING") HolmState.set("IDLE");
      },
      onError: (err) => {
        console.error(err);
        micBtn.classList.remove("active");
        HolmState.set("ERROR");
        setTimeout(() => HolmState.set("IDLE"), 1200);
      },
    });
  });

  // ===== 음성 출력 토글 =====
  speakToggleBtn.addEventListener("click", () => {
    const next = !HolmVoiceOutput.isEnabled();
    HolmVoiceOutput.setEnabled(next);
    speakToggleBtn.textContent = next ? "🔊" : "🔇";
    speakToggleBtn.classList.toggle("active", next);
  });

  // ===== 파일 업로드 =====
  fileBtn.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (!file) return;
    fileInput.value = "";

    HolmChat.renderFileNote(FilesTool.formatFileInfo(file));

    if (FilesTool.isImage(file)) {
      try {
        const base64 = await FilesTool.readAsBase64(file);
        pendingImage = { base64, mediaType: file.type, fileName: file.name };
        filePreview.textContent = `🖼 ${file.name} 첨부됨 — 메시지를 보내면 함께 전송돼요.`;
      } catch (e) {
        HolmChat.renderFileNote("이미지를 읽는 중 오류가 발생했어요.");
      }
    } else if (FilesTool.isText(file)) {
      try {
        const text = await FilesTool.readAsText(file);
        HolmRAG.addDocument(file.name, text);
        HolmChat.renderFileNote(`"${file.name}" 내용을 저장했어요. 이제 관련 질문에 참고할게요.`);
      } catch (e) {
        HolmChat.renderFileNote("파일을 읽는 중 오류가 발생했어요.");
      }
    } else {
      HolmChat.renderFileNote("이 파일 형식은 아직 지원하지 않아요. (txt/md/csv/json/이미지만 가능)");
    }
  });

  // ===== 설정 패널 (AI 두뇌: 내장 AI 기본 / 외부 API는 선택) =====
  const settingsPanel = document.getElementById("settingsPanel");
  const settingsBackdrop = document.getElementById("settingsBackdrop");
  const aiModeSelect = document.getElementById("aiModeSelect");
  const localAiBlock = document.getElementById("localAiBlock");
  const apiBlock = document.getElementById("apiBlock");
  const localModelSelect = document.getElementById("localModelSelect");
  const localModelStatus = document.getElementById("localModelStatus");
  const preloadModelBtn = document.getElementById("preloadModelBtn");
  const apiKeyInput = document.getElementById("apiKeyInput");
  const modelSelect = document.getElementById("modelSelect");
  const providerSelect = document.getElementById("providerSelect");
  const apiKeyStatus = document.getElementById("apiKeyStatus");
  const budgetModeSelect = document.getElementById("budgetModeSelect");
  const learningModeSelect = document.getElementById("learningModeSelect");
  const autoSaveSelect = document.getElementById("autoSaveSelect");

  function refreshApiKeyStatus() {
    if (HolmSettings.hasApiKey()) {
      apiKeyStatus.textContent = "✅ 키가 저장되어 있어요.";
      apiKeyStatus.className = "settings-status connected";
    } else {
      apiKeyStatus.textContent = "아직 키가 없어요.";
      apiKeyStatus.className = "settings-status";
    }
  }

  function toggleModeBlocks() {
    const mode = aiModeSelect.value;
    localAiBlock.style.display = mode === "local" ? "" : "none";
    apiBlock.style.display = mode === "api" ? "" : "none";
  }

  function openSettings() {
    aiModeSelect.value = HolmSettings.getMode();
    localModelSelect.value = HolmSettings.getLocalModel();
    apiKeyInput.value = HolmSettings.getApiKey();
    providerSelect.value = HolmSettings.getProvider();
    modelSelect.value = HolmSettings.getModel();
    budgetModeSelect.value = HolmSettings.getBudgetMode();
    learningModeSelect.value = HolmSettings.getLearningMode() ? "on" : "off";
    autoSaveSelect.value = HolmSettings.getAutoSaveMemory() ? "on" : "off";
    refreshApiKeyStatus();
    toggleModeBlocks();
    refreshEnvDiagnostics();
    if (HolmLocalAI.isReady(HolmSettings.getLocalModel())) {
      localModelStatus.textContent = "✅ 모델이 준비되어 있어요.";
      localModelStatus.className = "settings-status connected";
    } else {
      const err = HolmLocalAI.getLastError();
      if (err) {
        localModelStatus.textContent = `❌ ${err.userMessage} (${err.code})`;
        localModelStatus.className = "settings-status error";
      }
    }
    settingsPanel.classList.add("open");
    settingsBackdrop.classList.add("open");
  }

  async function refreshEnvDiagnostics() {
    const envEl = document.getElementById("envDiagnostics");
    envEl.textContent = "환경 검사 중...";
    try {
      const env = await HolmLocalAI.diagnoseEnvironment();
      const loaded = HolmLocalAI.getLoadedInfo();
      const lines = [
        `Browser: ${env.browser}${env.isIOS ? " (iOS)" : ""}`,
        `WebGPU: ${env.webgpu === "available" ? "사용 가능" : "사용 불가"}`,
        `WASM: ${env.wasm === "available" ? "사용 가능" : "사용 불가"}`,
        `Web Worker: ${env.worker === "available" ? "사용 가능" : "사용 불가"}`,
        `IndexedDB: ${env.indexedDB === "available" ? "사용 가능" : "사용 불가"}`,
        `Local AI: ${loaded.modelId ? `준비됨 (${loaded.device}/${loaded.dtype})` : "아직 로딩 안 됨"}`,
      ];
      envEl.textContent = lines.join("\n");
    } catch (e) {
      envEl.textContent = "환경 검사 실패: " + e.message;
    }
  }
  function closeSettings() {
    settingsPanel.classList.remove("open");
    settingsBackdrop.classList.remove("open");
  }

  document.getElementById("settingsToggleBtn").addEventListener("click", openSettings);
  document.getElementById("settingsCloseBtn").addEventListener("click", closeSettings);
  settingsBackdrop.addEventListener("click", closeSettings);

  aiModeSelect.addEventListener("change", () => {
    HolmSettings.save({ mode: aiModeSelect.value });
    toggleModeBlocks();
    HolmHUD.renderModuleList();
  });

  localModelSelect.addEventListener("change", () => {
    HolmSettings.save({ localModel: localModelSelect.value });
    localModelStatus.textContent = "아직 불러오지 않았어요.";
    localModelStatus.className = "settings-status";
  });

  // 내장 AI 다운로드 진행 상황 표시
  HolmLocalAI.onStatus((status) => {
    if (status.phase === "env-check") {
      localModelStatus.textContent = `환경 검사 완료 · 사용할 backend: ${status.device === "webgpu" ? "GPU(WebGPU)" : "CPU(WASM)"}`;
      localModelStatus.className = "settings-status";
    } else if (status.phase === "start") {
      localModelStatus.textContent = `모델을 준비하는 중이에요... (${status.device === "webgpu" ? "GPU" : "CPU"})`;
      localModelStatus.className = "settings-status";
    } else if (status.phase === "downloading") {
      const dtypeLabel = status.dtype ? ` [dtype=${status.dtype}]` : "";
      localModelStatus.textContent = `다운로드 중... ${status.pct}%${dtypeLabel}`;
      localModelStatus.className = "settings-status";
    } else if (status.phase === "ready") {
      localModelStatus.textContent = `✅ 모델 준비 완료! (${status.device}/${status.dtype})`;
      localModelStatus.className = "settings-status connected";
      refreshEnvDiagnostics();
      HolmHUD.renderModuleList();
    } else if (status.phase === "error") {
      localModelStatus.textContent = `❌ ${status.userMessage || "모델을 불러오지 못했어요."} (원인 코드: ${status.code || "unknown"})`;
      localModelStatus.className = "settings-status error";
      HolmHUD.renderModuleList();
    }
  });

  preloadModelBtn.addEventListener("click", async () => {
    preloadModelBtn.disabled = true;
    try {
      await HolmLocalAI.ensureLoaded(HolmSettings.getLocalModel());
    } catch (e) {
      console.error(e);
    } finally {
      preloadModelBtn.disabled = false;
    }
  });

  document.getElementById("saveApiKeyBtn").addEventListener("click", () => {
    HolmSettings.save({ apiKey: apiKeyInput.value, model: modelSelect.value });
    refreshApiKeyStatus();
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote("설정을 저장했어요.");
  });

  document.getElementById("clearApiKeyBtn").addEventListener("click", () => {
    HolmSettings.clearApiKey();
    apiKeyInput.value = "";
    aiModeSelect.value = "local";
    toggleModeBlocks();
    refreshApiKeyStatus();
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote("API 키를 삭제하고 내장 AI로 전환했어요.");
  });

  providerSelect.addEventListener("change", () => {
    HolmSettings.save({ provider: providerSelect.value });
  });

  budgetModeSelect.addEventListener("change", () => {
    HolmSettings.save({ budgetMode: budgetModeSelect.value });
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote(
      budgetModeSelect.value === "free_only"
        ? "비용 보호 모드를 켰어요. 이제부터 무료(내장 AI)만 사용해요."
        : "외부 유료 API 호출을 허용했어요."
    );
  });

  learningModeSelect.addEventListener("change", () => {
    HolmSettings.save({ learningMode: learningModeSelect.value === "on" });
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote(
      learningModeSelect.value === "on" ? "Learning Mode를 켰어요." : "Learning Mode를 껐어요. 이제 새 기억을 저장하지 않아요."
    );
  });

  autoSaveSelect.addEventListener("change", () => {
    HolmSettings.save({ autoSaveMemory: autoSaveSelect.value === "on" });
  });

  // ===== 기억(Memory) 관리 패널 =====
  const memoryPanel = document.getElementById("memoryPanel");
  const memoryBackdrop = document.getElementById("memoryBackdrop");

  function openMemoryPanel() {
    HolmMemoryUI.renderList();
    memoryPanel.classList.add("open");
    memoryBackdrop.classList.add("open");
  }
  function closeMemoryPanel() {
    memoryPanel.classList.remove("open");
    memoryBackdrop.classList.remove("open");
  }
  document.getElementById("memoryToggleBtn").addEventListener("click", openMemoryPanel);
  document.getElementById("memoryCloseBtn").addEventListener("click", closeMemoryPanel);
  memoryBackdrop.addEventListener("click", closeMemoryPanel);
});
