/**
 * app.js
 * 모든 모듈을 초기화하고 UI 이벤트를 연결하는 진입점.
 */

document.addEventListener("DOMContentLoaded", () => {
  // ===== 핵심 모듈 초기화 =====
  HolmCore.init(document.getElementById("holmCore"));
  HolmHUD.init();
  HolmChat.init();
  HolmMemoryUI.init();
  HolmState.set("IDLE");

  const chatInput = document.getElementById("chatInput");
  const sendBtn = document.getElementById("sendBtn");
  const micBtn = document.getElementById("micBtn");
  const speakToggleBtn = document.getElementById("speakToggleBtn");
  const fileBtn = document.getElementById("fileBtn");
  const fileInput = document.getElementById("fileInput");
  const filePreview = document.getElementById("filePreview");

  let pendingImage = null; // { base64, mediaType, fileName }

  // 입력창 높이 자동 조절
  chatInput.addEventListener("input", () => {
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + "px";
  });

  chatInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });

  sendBtn.addEventListener("click", handleSend);

  function handleSend() {
    const text = chatInput.value;
    if (!text.trim() && !pendingImage) return;
    chatInput.value = "";
    chatInput.style.height = "auto";
    const image = pendingImage;
    pendingImage = null;
    filePreview.textContent = "";
    HolmChat.sendUserMessage(text, image);
  }

  // ===== 음성 입력 =====
  micBtn.addEventListener("click", () => {
    if (!HolmVoiceInput.isSupported()) {
      HolmChat.renderFileNote("이 브라우저는 음성 인식을 지원하지 않아요.");
      return;
    }
    micBtn.classList.add("active");
    HolmState.set("LISTENING");

    HolmVoiceInput.start({
      onResult: (text) => {
        chatInput.value = text;
        handleSend();
      },
      onEnd: () => {
        micBtn.classList.remove("active");
        if (HolmState.get() === "LISTENING") HolmState.set("IDLE");
      },
      onError: (err) => {
        console.error(err);
        micBtn.classList.remove("active");
        HolmState.set("ERROR");
        setTimeout(() => HolmState.set("IDLE"), 1200);
      },
    });
  });

  // ===== 음성 출력 토글 =====
  speakToggleBtn.addEventListener("click", () => {
    const next = !HolmVoiceOutput.isEnabled();
    HolmVoiceOutput.setEnabled(next);
    speakToggleBtn.textContent = next ? "🔊" : "🔇";
    speakToggleBtn.classList.toggle("active", next);
  });

  // ===== 파일 업로드 =====
  fileBtn.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (!file) return;
    fileInput.value = "";

    HolmChat.renderFileNote(FilesTool.formatFileInfo(file));

    if (FilesTool.isImage(file)) {
      try {
        const base64 = await FilesTool.readAsBase64(file);
        pendingImage = { base64, mediaType: file.type, fileName: file.name };
        filePreview.textContent = `🖼 ${file.name} 첨부됨 — 메시지를 보내면 함께 전송돼요.`;
      } catch (e) {
        HolmChat.renderFileNote("이미지를 읽는 중 오류가 발생했어요.");
      }
    } else if (FilesTool.isText(file)) {
      try {
        const text = await FilesTool.readAsText(file);
        HolmRAG.addDocument(file.name, text);
        HolmChat.renderFileNote(`"${file.name}" 내용을 저장했어요. 이제 관련 질문에 참고할게요.`);
      } catch (e) {
        HolmChat.renderFileNote("파일을 읽는 중 오류가 발생했어요.");
      }
    } else {
      HolmChat.renderFileNote("이 파일 형식은 아직 지원하지 않아요. (txt/md/csv/json/이미지만 가능)");
    }
  });

  // ===== 설정 패널 (AI 두뇌: 내장 AI 기본 / 외부 API는 선택) =====
  const settingsPanel = document.getElementById("settingsPanel");
  const settingsBackdrop = document.getElementById("settingsBackdrop");
  const aiModeSelect = document.getElementById("aiModeSelect");
  const localAiBlock = document.getElementById("localAiBlock");
  const apiBlock = document.getElementById("apiBlock");
  const localModelSelect = document.getElementById("localModelSelect");
  const localModelStatus = document.getElementById("localModelStatus");
  const preloadModelBtn = document.getElementById("preloadModelBtn");
  const apiKeyInput = document.getElementById("apiKeyInput");
  const modelSelect = document.getElementById("modelSelect");
  const providerSelect = document.getElementById("providerSelect");
  const apiKeyStatus = document.getElementById("apiKeyStatus");
  const budgetModeSelect = document.getElementById("budgetModeSelect");
  const learningModeSelect = document.getElementById("learningModeSelect");
  const autoSaveSelect = document.getElementById("autoSaveSelect");

  function refreshApiKeyStatus() {
    if (HolmSettings.hasApiKey()) {
      apiKeyStatus.textContent = "✅ 키가 저장되어 있어요.";
      apiKeyStatus.className = "settings-status connected";
    } else {
      apiKeyStatus.textContent = "아직 키가 없어요.";
      apiKeyStatus.className = "settings-status";
    }
  }

  function toggleModeBlocks() {
    const mode = aiModeSelect.value;
    localAiBlock.style.display = mode === "local" ? "" : "none";
    apiBlock.style.display = mode === "api" ? "" : "none";
  }

  function openSettings() {
    aiModeSelect.value = HolmSettings.getMode();
    localModelSelect.value = HolmSettings.getLocalModel();
    apiKeyInput.value = HolmSettings.getApiKey();
    providerSelect.value = HolmSettings.getProvider();
    modelSelect.value = HolmSettings.getModel();
    budgetModeSelect.value = HolmSettings.getBudgetMode();
    learningModeSelect.value = HolmSettings.getLearningMode() ? "on" : "off";
    autoSaveSelect.value = HolmSettings.getAutoSaveMemory() ? "on" : "off";
    refreshApiKeyStatus();
    toggleModeBlocks();
    refreshAiStatusBox();
    settingsPanel.classList.add("open");
    settingsBackdrop.classList.add("open");
  }

  // ===== Local AI 상태 박스 (요청된 5개 필드: 상태/Backend/Model/Error code/Error message) =====
  function refreshAiStatusBox() {
    const info = HolmLocalAI.getLoadedInfo();
    const err = HolmLocalAI.getLastError();
    document.getElementById("statLocalAiState").textContent = info.modelId
      ? "✅ 준비 완료"
      : err
      ? "❌ 실패"
      : "아직 불러오지 않음";
    document.getElementById("statBackend").textContent = info.device || "-";
    document.getElementById("statModel").textContent = info.modelId
      ? `${info.modelId} (dtype=${info.dtype})`
      : HolmSettings.getLocalModel();
    document.getElementById("statErrorCode").textContent = err ? err.stage || "unknown" : "-";
    document.getElementById("statErrorMessage").textContent = err ? err.message : "-";
  }

  // ===== 실시간 진단 로그 (HOLM DIAGNOSTICS) =====
  let liveLog = [];
  function _appendLive(line) {
    liveLog.push(line);
    if (liveLog.length > 80) liveLog.shift();
    document.getElementById("envDiagnostics").textContent = liveLog.join("\n");
  }

  function renderFileLog(files) {
    const box = document.getElementById("fileLogBox");
    if (!files || !files.length) {
      box.textContent = "아직 없음.";
      return;
    }
    box.textContent = files
      .map((f) => {
        const sizeStr = typeof f.bytes === "number" ? `${(f.bytes / 1024 / 1024).toFixed(2)}MB` : "-";
        const mark = f.status === "success" ? "✓" : f.status === "failed" ? "✗" : "…";
        return `${mark} ${f.fileName} [HTTP ${f.httpStatus || "-"}] ${sizeStr}${f.error ? " — " + f.error : ""}`;
      })
      .join("\n");
  }

  function formatFullDiagnostics(report) {
    const env = report.env || {};
    const files = report.files || [];
    const stages = report.stages || [];

    const fileStatus = (pattern) => {
      const matches = files.filter((f) => pattern.test(f.fileName));
      if (!matches.length) return "확인 안 됨";
      return matches.every((f) => f.status === "success") ? "OK" : "FAILED";
    };
    const cdnStage = stages.find((s) => s.stage === "cdn_import");
    const cdnStatus = cdnStage ? (cdnStage.status === "success" ? "OK" : "FAILED") : "확인 안 됨";

    const lines = [
      "HOLM DIAGNOSTICS",
      "",
      `Browser: ${env.browser || "?"}`,
      `Platform: ${env.platform || "?"}`,
      `WebGPU: ${env.webgpu || "?"}`,
      `WebAssembly: ${env.wasm || "?"}`,
      `IndexedDB: ${env.indexedDB || "?"}`,
      `CDN: ${cdnStatus}`,
      `Transformers.js: ${cdnStatus}`,
      `Model config: ${fileStatus(/config\.json$/i)}`,
      `Tokenizer: ${fileStatus(/tokenizer/i)}`,
      `ONNX model: ${fileStatus(/\.onnx(_data)?$/i)}`,
    ];

    if (report.lastError) {
      lines.push("", "Error:");
      lines.push(`  stage: ${report.lastError.stage || "?"}`);
      lines.push(`  name: ${report.lastError.name}`);
      lines.push(`  message: ${report.lastError.message}`);
      if (report.lastError.cause) lines.push(`  cause: ${report.lastError.cause.name}: ${report.lastError.cause.message}`);
    } else {
      lines.push("", "Error: 없음");
    }
    return lines.join("\n");
  }

  function closeSettings() {
    settingsPanel.classList.remove("open");
    settingsBackdrop.classList.remove("open");
  }

  document.getElementById("settingsToggleBtn").addEventListener("click", openSettings);
  document.getElementById("settingsCloseBtn").addEventListener("click", closeSettings);
  settingsBackdrop.addEventListener("click", closeSettings);

  aiModeSelect.addEventListener("change", () => {
    HolmSettings.save({ mode: aiModeSelect.value });
    toggleModeBlocks();
    HolmHUD.renderModuleList();
  });

  localModelSelect.addEventListener("change", () => {
    HolmSettings.save({ localModel: localModelSelect.value });
    refreshAiStatusBox();
  });

  // 내장 AI 로딩의 모든 단계를 실시간으로 기록 (START/SUCCESS/FAILED)
  HolmLocalAI.onStatus((status) => {
    refreshAiStatusBox();

    if (status.phase === "env-check") {
      _appendLive(
        `[env] Browser=${status.env.browser} iOS=${status.env.isIOS} WebGPU=${status.env.webgpu} WASM=${status.env.wasm} → 선택된 backend=${status.device}`
      );
    } else if (status.phase === "stage") {
      const mark = status.status === "success" ? "✓" : status.status === "failed" ? "✗" : "…";
      const extra = status.status === "failed" && status.detail ? ` — ${status.detail.message}` : "";
      _appendLive(`${mark} ${status.stage}${extra}`);
    } else if (status.phase === "downloading") {
      _appendLive(`  ↳ 다운로드 ${status.file || ""} ${status.pct}% (dtype=${status.dtype}, device=${status.device})`);
    } else if (status.phase === "file") {
      const mark = status.status === "success" ? "✓" : status.status === "failed" ? "✗" : "…";
      _appendLive(`  ↳ 파일 ${mark} ${status.fileName}${status.httpStatus ? " HTTP" + status.httpStatus : ""}`);
      renderFileLog(HolmLocalAI.getDiagnosticsReport().files);
    } else if (status.phase === "ready") {
      _appendLive(`✅ 모델 준비 완료 (${status.device}/${status.dtype})`);
      HolmHUD.renderModuleList();
    } else if (status.phase === "error") {
      _appendLive(`❌ 오류 [stage=${status.stage}] ${status.name}: ${status.message}`);
      HolmHUD.renderModuleList();
    }
  });

  preloadModelBtn.addEventListener("click", async () => {
    preloadModelBtn.disabled = true;
    liveLog = [];
    _appendLive("모델 로딩을 시작합니다...");
    try {
      await HolmLocalAI.ensureLoaded(HolmSettings.getLocalModel());
    } catch (e) {
      console.error(e);
    } finally {
      preloadModelBtn.disabled = false;
    }
  });

  document.getElementById("runDiagnosticsBtn").addEventListener("click", async () => {
    const envEl = document.getElementById("envDiagnostics");
    envEl.textContent = "진단 실행 중... (모델을 실제로 불러오면서 확인해요)";
    liveLog = [];
    try {
      await HolmLocalAI.ensureLoaded(HolmSettings.getLocalModel());
    } catch (e) {
      // 실패해도 report에 상세가 담겨있으니 아래에서 그대로 보여준다
    }
    const report = HolmLocalAI.getDiagnosticsReport();
    envEl.textContent = formatFullDiagnostics(report);
    renderFileLog(report.files);
    refreshAiStatusBox();
    HolmHUD.renderModuleList();
  });

  // ===== 개별 진단 테스트 버튼 =====
  document.getElementById("testBtnGrid").addEventListener("click", async (e) => {
    const btn = e.target.closest(".test-btn");
    if (!btn) return;
    const test = btn.dataset.test;
    const modelId = HolmSettings.getLocalModel();
    const resultsEl = document.getElementById("testResults");

    btn.classList.remove("pass", "fail");
    btn.classList.add("running");
    resultsEl.textContent = `[${btn.textContent}] 실행 중...`;

    let result;
    try {
      switch (test) {
        case "cdn": result = await HolmLocalAI.testCDN(); break;
        case "wasm": result = await HolmLocalAI.testWasm(); break;
        case "hf": result = await HolmLocalAI.testHFConnectivity(modelId); break;
        case "tokenizer": result = await HolmLocalAI.testTokenizer(modelId); break;
        case "model": result = await HolmLocalAI.testModelFile(modelId); break;
        case "pipeline": result = await HolmLocalAI.testPipeline(modelId); break;
        case "generate": result = await HolmLocalAI.testGenerate(modelId); break;
        default: result = { ok: false, detail: { message: "알 수 없는 테스트" } };
      }
    } catch (err) {
      result = { ok: false, detail: { message: err.message } };
    }

    btn.classList.remove("running");
    btn.classList.add(result.ok ? "pass" : "fail");
    resultsEl.textContent = `[${btn.textContent}] ${result.ok ? "✅ 성공" : "❌ 실패"}\n` + JSON.stringify(result, null, 2);
  });

  document.getElementById("saveApiKeyBtn").addEventListener("click", () => {
    HolmSettings.save({ apiKey: apiKeyInput.value, model: modelSelect.value });
    refreshApiKeyStatus();
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote("설정을 저장했어요.");
  });

  document.getElementById("clearApiKeyBtn").addEventListener("click", () => {
    HolmSettings.clearApiKey();
    apiKeyInput.value = "";
    aiModeSelect.value = "local";
    toggleModeBlocks();
    refreshApiKeyStatus();
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote("API 키를 삭제하고 내장 AI로 전환했어요.");
  });

  providerSelect.addEventListener("change", () => {
    HolmSettings.save({ provider: providerSelect.value });
  });

  budgetModeSelect.addEventListener("change", () => {
    HolmSettings.save({ budgetMode: budgetModeSelect.value });
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote(
      budgetModeSelect.value === "free_only"
        ? "비용 보호 모드를 켰어요. 이제부터 무료(내장 AI)만 사용해요."
        : "외부 유료 API 호출을 허용했어요."
    );
  });

  learningModeSelect.addEventListener("change", () => {
    HolmSettings.save({ learningMode: learningModeSelect.value === "on" });
    HolmHUD.renderModuleList();
    HolmChat.renderFileNote(
      learningModeSelect.value === "on" ? "Learning Mode를 켰어요." : "Learning Mode를 껐어요. 이제 새 기억을 저장하지 않아요."
    );
  });

  autoSaveSelect.addEventListener("change", () => {
    HolmSettings.save({ autoSaveMemory: autoSaveSelect.value === "on" });
  });

  // ===== 기억(Memory) 관리 패널 =====
  const memoryPanel = document.getElementById("memoryPanel");
  const memoryBackdrop = document.getElementById("memoryBackdrop");

  function openMemoryPanel() {
    HolmMemoryUI.renderList();
    memoryPanel.classList.add("open");
    memoryBackdrop.classList.add("open");
  }
  function closeMemoryPanel() {
    memoryPanel.classList.remove("open");
    memoryBackdrop.classList.remove("open");
  }
  document.getElementById("memoryToggleBtn").addEventListener("click", openMemoryPanel);
  document.getElementById("memoryCloseBtn").addEventListener("click", closeMemoryPanel);
  memoryBackdrop.addEventListener("click", closeMemoryPanel);
});
