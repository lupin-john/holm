/**
 * chat.js
 * 채팅 메시지 렌더링과 전송 흐름을 담당.
 *
 * 안정성: HolmBrain.handleUserInput()이 내부적으로 오류를 잡아서 문자열로
 * 돌려주는 게 기본 설계지만, 혹시 예상 못 한 곳에서 예외가 튀어나와도
 * 이 함수의 try/catch/finally가 최종 안전망 역할을 해서 상태가
 * THINKING/PROCESSING/LISTENING에 영원히 멈춰있지 않도록 보장한다.
 */

const HolmChat = (() => {
  let messagesEl;

  function init() {
    messagesEl = document.getElementById("chatMessages");
    _renderHistory();
  }

  function _renderHistory() {
    const history = HolmStorage.loadHistory();
    if (!history.length) {
      _appendSystemNote("Holm과의 대화가 시작됩니다.");
      return;
    }
    history.forEach((m) => _renderMessage(m.role, m.text, false));
    _scrollToBottom();
  }

  function _renderMessage(role, text, scroll = true) {
    const div = document.createElement("div");
    div.className = `msg ${role}`;
    div.textContent = text;
    messagesEl.appendChild(div);
    if (scroll) _scrollToBottom();
    return div;
  }

  function _appendSystemNote(text) {
    const div = document.createElement("div");
    div.className = "msg system";
    div.textContent = text;
    messagesEl.appendChild(div);
    _scrollToBottom();
  }

  function _scrollToBottom() {
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  /**
   * @param {string} text 사용자 입력 텍스트
   * @param {{base64:string, mediaType:string, fileName:string}|null} image 첨부 이미지 (있으면)
   */
  async function sendUserMessage(text, image = null) {
    if (!text.trim() && !image) return;

    const displayText = image ? `${text || "(이미지를 보냈어요)"} 📎${image.fileName}` : text;
    _renderMessage("user", displayText);
    HolmStorage.appendMessage("user", displayText);

    let reply;
    let hadError = false;

    try {
      reply = await HolmBrain.handleUserInput(text, image);
    } catch (e) {
      // 안전망: brain.js가 못 잡은 예외가 여기까지 올라온 경우
      console.error("[HolmChat] 처리되지 않은 오류:", e);
      reply = "예상치 못한 오류가 발생했어요. 다시 시도해주세요. (" + (e.message || "알 수 없는 오류") + ")";
      hadError = true;
    }

    _renderMessage("holm", reply);
    HolmStorage.appendMessage("holm", reply);

    if (hadError) {
      HolmState.set("ERROR");
      setTimeout(() => HolmState.set("IDLE"), 1500);
      return reply;
    }

    // 정상/처리된-오류 응답 모두 여기로 온다 — 반드시 SPEAKING → IDLE로 돌아온다.
    HolmState.set("SPEAKING");
    let settled = false;
    const backToIdle = () => {
      if (settled) return;
      settled = true;
      HolmState.set("IDLE");
    };

    HolmVoiceOutput.speak(reply, { onEnd: backToIdle });
    // speak()가 비활성 상태이거나 onEnd가 호출되지 않는 예외 상황에 대비한 안전망 타이머
    setTimeout(backToIdle, HolmVoiceOutput.isEnabled() ? 15000 : 600);

    return reply;
  }

  return { init, sendUserMessage, renderFileNote: (text) => _appendSystemNote(text) };
})();
