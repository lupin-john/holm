/**
 * chat.js
 * 채팅 메시지 렌더링과 전송 흐름을 담당.
 *
 * 안정성: HolmBrain.handleUserInput()이 내부적으로 오류를 잡아서 문자열로
 * 돌려주는 게 기본 설계지만, 혹시 예상 못 한 곳에서 예외가 튀어나와도
 * 이 함수의 try/catch/finally가 최종 안전망 역할을 해서 상태가
 * THINKING/PROCESSING/LISTENING에 영원히 멈춰있지 않도록 보장한다.
 *
 * v3.4: Local AI 계산이 Web Worker로 옮겨지면서 오래 걸릴 수 있는 첫 로딩/
 * 생성 상황을 사용자가 알 수 있도록, "생각 중..." placeholder 메시지를
 * 실시간으로 갱신한다 (다운로드 %, 생성 시작 등).
 */

const HolmChat = (() => {
  let messagesEl;
  let activePlaceholder = null;

  function init() {
    messagesEl = document.getElementById("chatMessages");
    _renderHistory();

    // Local AI 진행 상황을 placeholder 메시지에 실시간 반영
    if (window.HolmLocalAI) {
      HolmLocalAI.onStatus((status) => {
        if (!activePlaceholder) return;
        if (status.phase === "downloading" && typeof status.pct === "number") {
          activePlaceholder.textContent = `모델을 처음 준비하는 중이에요... ${status.pct}% (한 번만 받으면 다음부터 빨라져요)`;
        } else if (status.phase === "stage" && status.stage === "cdn_import" && status.status === "start") {
          activePlaceholder.textContent = "AI 라이브러리를 불러오는 중...";
        } else if (status.phase === "stage" && status.stage === "generate" && status.status === "start") {
          activePlaceholder.textContent = "생성 중... (기기 성능에 따라 시간이 걸릴 수 있어요)";
        } else if (status.phase === "ready") {
          activePlaceholder.textContent = "모델 준비 완료, 답변을 생성하고 있어요...";
        }
      });
    }
  }

  function _renderHistory() {
    const history = HolmStorage.loadHistory();
    if (!history.length) {
      _appendSystemNote("Holm과의 대화가 시작됩니다.");
      return;
    }
    history.forEach((m) => _renderMessage(m.role, m.text, false));
    _scrollToBottom();
  }

  function _renderMessage(role, text, scroll = true) {
    const div = document.createElement("div");
    div.className = `msg ${role}`;
    div.textContent = text;
    messagesEl.appendChild(div);
    if (scroll) _scrollToBottom();
    return div;
  }

  function _appendSystemNote(text) {
    const div = document.createElement("div");
    div.className = "msg system";
    div.textContent = text;
    messagesEl.appendChild(div);
    _scrollToBottom();
  }

  function _scrollToBottom() {
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  /**
   * @param {string} text 사용자 입력 텍스트
   * @param {{base64:string, mediaType:string, fileName:string}|null} image 첨부 이미지 (있으면)
   */
  async function sendUserMessage(text, image = null) {
    if (!text.trim() && !image) return;

    const displayText = image ? `${text || "(이미지를 보냈어요)"} 📎${image.fileName}` : text;
    _renderMessage("user", displayText);
    HolmStorage.appendMessage("user", displayText);

    // 답변이 오기 전까지 보여줄 placeholder (실시간으로 진행 상황 갱신됨)
    activePlaceholder = _renderMessage("holm", "생각하는 중...");

    let reply;
    let hadError = false;

    try {
      reply = await HolmBrain.handleUserInput(text, image);
    } catch (e) {
      console.error("[HolmChat] 처리되지 않은 오류:", e);
      reply = "예상치 못한 오류가 발생했어요. 다시 시도해주세요. (" + (e.message || "알 수 없는 오류") + ")";
      hadError = true;
    }

    activePlaceholder.textContent = reply;
    _scrollToBottom();
    activePlaceholder = null;
    HolmStorage.appendMessage("holm", reply);

    if (hadError) {
      HolmState.set("ERROR");
      setTimeout(() => HolmState.set("IDLE"), 1500);
      return reply;
    }

    HolmState.set("SPEAKING");
    let settled = false;
    const backToIdle = () => {
      if (settled) return;
      settled = true;
      HolmState.set("IDLE");
    };

    HolmVoiceOutput.speak(reply, { onEnd: backToIdle });
    setTimeout(backToIdle, HolmVoiceOutput.isEnabled() ? 15000 : 600);

    return reply;
  }

  return { init, sendUserMessage, renderFileNote: (text) => _appendSystemNote(text) };
})();
