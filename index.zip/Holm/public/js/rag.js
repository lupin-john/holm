/**
 * rag.js
 * v1의 간단한 RAG(검색 증강 생성) 구현.
 *
 * 정식 RAG(임베딩 + vector DB)는 아니고, 업로드된 텍스트 파일을 chunk로 쪼개서
 * localStorage에 저장한 뒤, 사용자의 질문과 겹치는 단어가 많은 chunk를
 * 찾아서 AI에게 참고 자료로 넘겨주는 "키워드 기반" 버전이다.
 *
 * 인터페이스(addDocument/retrieve)는 유지한 채,
 * 나중에 실제 embedding + vector DB로 내부 구현만 교체할 수 있다.
 */

const HolmRAG = (() => {
  const KEY = "holm_rag_documents_v1";
  const CHUNK_SIZE = 500;
  const MAX_DOCS = 20;

  function _load() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function _save(docs) {
    localStorage.setItem(KEY, JSON.stringify(docs));
  }

  function _chunk(text) {
    const chunks = [];
    for (let i = 0; i < text.length; i += CHUNK_SIZE) {
      chunks.push(text.slice(i, i + CHUNK_SIZE));
    }
    return chunks;
  }

  function addDocument(filename, text) {
    const docs = _load();
    const doc = {
      id: Date.now().toString(36),
      filename,
      chunks: _chunk(text),
      addedAt: new Date().toISOString(),
    };
    docs.push(doc);
    while (docs.length > MAX_DOCS) docs.shift();
    _save(docs);
    return doc;
  }

  function listDocuments() {
    return _load().map((d) => ({ id: d.id, filename: d.filename, addedAt: d.addedAt }));
  }

  function removeDocument(id) {
    _save(_load().filter((d) => d.id !== id));
  }

  function clearAll() {
    _save([]);
  }

  // 아주 단순한 단어-겹침 스코어링 (TF 방식조차 아닌 매칭 카운트)
  function retrieve(query, topK = 2) {
    const docs = _load();
    if (!docs.length) return [];

    const queryTokens = _tokenize(query);
    if (!queryTokens.length) return [];

    const scored = [];
    docs.forEach((doc) => {
      doc.chunks.forEach((chunk) => {
        const chunkTokens = _tokenize(chunk);
        const overlap = queryTokens.filter((t) => chunkTokens.includes(t)).length;
        if (overlap > 0) {
          scored.push({ filename: doc.filename, chunk, score: overlap });
        }
      });
    });

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, topK);
  }

  function _tokenize(text) {
    return text
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .split(/\s+/)
      .filter((t) => t.length > 1);
  }

  return { addDocument, listDocuments, removeDocument, clearAll, retrieve };
})();
