# rag/

v1에서는 아직 구현되지 않았습니다.

**v7 계획 파이프라인:**

```
documents → text extraction → chunking → embedding → vector database → retrieval → AI Brain
```

파일 업로드(`tools-files.js`)와 백엔드가 먼저 갖춰진 뒤(v6),
이 폴더에서 청킹/임베딩/검색 로직을 구현할 예정입니다.
