# HOLM — 개인용 AI 비서 (v3)

Holm은 영화 속 AI 비서에서 영감을 받았지만, 대사나 디자인을 그대로 베끼지 않고
독자적인 UI(다크 네이비 + 시안 네온 HUD)로 만든 개인용 AI 프로젝트입니다.

**v3의 핵심 목표:** "Holm이 대화하면서 중요한 정보를 기억하고, 정리하고,
다음 대화에서 활용하는 시스템"을 만드는 것. 실제 모델 가중치를 재학습(LoRA)하지는
않지만, 나중에 그렇게 할 수 있도록 데이터를 준비해둡니다.

**비용 우선순위:** 유료 API는 절대 필수가 아닙니다. 기본값은 여전히 브라우저에
내장된 오픈소스 소형 모델(Qwen2.5)이고, Budget Mode를 "무료만 사용"으로 두면
API 키를 넣어도 실제로는 절대 호출되지 않습니다.

---

## 1. 빠른 실행 방법

```bash
cd Holm/public
python3 -m http.server 8000
```
`http://localhost:8000` 접속 (또는 GitHub Pages로 배포).

> 🧠 모델 다운로드, IndexedDB 저장, 음성 인식 모두 실제 웹 환경(https 또는
> localhost)이 필요해요. Claude 앱 미리보기처럼 네트워크가 제한된 샌드박스에서는
> 일부 기능이 실패할 수 있습니다.

---

## 2. 수정한 파일 목록 (기존 v2 대비)

- `public/index.html` — 기억 관리 패널, 승인/저장 토스트, Learning Mode·Auto Save·Budget Mode·Provider 설정 UI 추가
- `public/css/style.css` — 위 UI들을 위한 스타일 추가
- `public/js/settings.js` — budgetMode, learningMode, autoSaveMemory, provider 필드 추가
- `public/js/model-adapter.js` — 단일 어댑터 방식 → AI Router(Local/Anthropic/OpenAI/Gemini) + Budget Mode 강제 + 실패 시 자동 폴백 체인으로 재구성
- `public/js/prompt.js` — Memory/Knowledge 블록 추가, Learning Mode일 때 Reflection 추출 지시문 삽입
- `public/js/brain.js` — 기억 명령을 MemoryDB 기반으로 변경, Context Retrieval → AI 호출 → Reflection → 대화 로그 기록 흐름 추가
- `public/js/hud.js` — 모듈 목록에 MEMORY(개수)/KNOWLEDGE(개수)/REFLECTION 상태 표시
- `public/js/memory.js` — v3에서 미사용으로 전환됨을 명시하는 주석만 변경 (삭제하지 않음)

## 3. 새로 만든 파일 목록

- `public/js/db.js` — IndexedDB 공용 래퍼
- `public/js/text-sim.js` — 단어 겹침 기반 유사도 계산 (Jaccard)
- `public/js/memory-db.js` — Memory 시스템 본체
- `public/js/knowledge-db.js` — Knowledge DB 본체
- `public/js/reflection.js` — Reflection Engine
- `public/js/retrieval.js` — Context Retrieval
- `public/js/conversation-log.js` — 대화 로그 (IndexedDB) + JSONL 내보내기
- `public/js/export-import.js` — Memory/Knowledge JSON Export/Import
- `public/js/memory-ui.js` — 기억 관리 UI 로직 (목록/수정/삭제/검색/승인 토스트)
- `public/js/diagnostics.js` — 콘솔 self-test (`HolmDiagnostics.run()`)

---

## v3.1 — iPhone Safari "Load failed" 수정 (안정성 패치)

### 가장 가능성 높았던 원인
1. **WebGPU 오탐**: Safari가 `navigator.gpu`를 부분적으로 노출해도 실제로는
   동작하지 않는 경우가 있어, 예전 코드는 이걸 믿고 WebGPU 경로로 들어갔다가
   실패했을 가능성이 큼.
2. **dtype 불일치**: `dtype: "q4"`로 고정되어 있었는데, 해당 모델 저장소에
   q4 양자화 파일이 없거나 접근이 막히면 파이프라인 생성 자체가 실패하고,
   Safari는 이걸 뭉뚱그려 "Load failed"라고만 보여줌.
3. 위 두 가지가 겹치면 사용자에게는 원인을 알 수 없는 "Load failed"만 보이고,
   개발자 콘솔에도 자세한 정보가 안 남아서 디버깅이 불가능했음.

### 수정한 파일
- **`public/js/local-ai.js`** (전면 개선)
  - Safari/iOS를 감지하면 WebGPU를 아예 시도하지 않고 WASM을 강제 사용
  - WebGPU는 `navigator.gpu` 존재 여부가 아니라 `requestAdapter()`를 실제
    호출해서 확인 (3초 타임아웃)
  - WASM도 더미 모듈을 실제로 `instantiate`해서 진짜 동작하는지 확인
  - `dtype`을 q4 → q8 → fp32 순서로 자동 재시도 (하나가 없어도 다음 걸로 폴백)
  - CDN import에 20초 타임아웃, 생성 요청에 60초 타임아웃을 걸어서
    무한 대기(페이지 멈춤)를 방지
  - 오류를 `cdn_import_failed / model_download_failed / wasm_init_failed /
    out_of_memory / timeout / unknown_error`로 분류하고, 각각 사용자용 한국어
    메시지 + 개발자 콘솔용 상세 정보(error.name/message/stack 일부/device/env)를
    함께 남김
  - `diagnoseEnvironment()`, `getLastError()`, `getLoadedInfo()` 추가로
    Settings 패널과 diagnostics.js에서 상태를 조회할 수 있게 함
- **`public/js/chat.js`** — `sendUserMessage`에 try/catch/finally 안전망 추가.
  brain.js가 못 잡은 예외가 올라와도 반드시 ERROR → IDLE로 복귀하고,
  음성 출력이 끝나지 않는 예외 상황에도 타임아웃으로 강제 복귀.
- **`public/js/hud.js`** — MEMORY/KNOWLEDGE 상태를 BRAIN(AI) 상태와 완전히
  분리해서 표시. AI가 실패해도 "MEMORY ONLINE (n개)"는 그대로 보임.
- **`public/index.html` / `public/css/style.css`** — 설정 패널에 환경 진단
  결과를 보여주는 작은 텍스트 영역 추가 (기존 HUD/Core/Memory UI 디자인은
  변경하지 않음).

### 새로 만든 파일
- **`public/js/diagnostics.js`** — 콘솔에서 `HolmDiagnostics.run()`을 실행하면
  환경 감지 / IndexedDB(Memory) / Knowledge DB / 대화 로그 / RAG / Local AI
  로딩을 순서대로 점검해서 표로 보여준다. AI가 실패해도 나머지는 통과해야 정상.

### iPhone Safari에서 테스트하는 방법
1. `holm-standalone.html`을 iPhone Safari로 직접 연다 (다운로드 후 파일 앱에서
   열거나 GitHub Pages 배포 후 접속 — `file://`는 일부 기능이 제한될 수 있음).
2. ⚙ 설정을 열면 "환경 검사" 결과가 텍스트로 보인다:
   ```
   Browser: Safari (iOS)
   WebGPU: 사용 불가
   WASM: 사용 가능
   Web Worker: 사용 가능
   IndexedDB: 사용 가능
   Local AI: 아직 로딩 안 됨
   ```
3. "지금 모델 다운로드하기"를 누르고 진행 상황(다운로드 %, dtype)을 지켜본다.
4. 실패하면 이제 "Load failed" 대신 `모델 다운로드에 실패했어요 (model_download_failed)`
   처럼 원인이 표시되고, Safari 개발자 콘솔(Mac에 연결 후 Web Inspector)에
   `error.name/message/stack`이 자세히 찍힌다.

### Local AI가 실패해도 Memory를 테스트하는 방법
Local AI 로딩과 Memory 시스템은 코드상 완전히 독립적이다 (brain.js가 메모리
명령을 처리할 때는 애초에 AI를 호출하지 않음). 확인하려면:
1. AI 연결 없이 채팅창에 `기억해: 나는 매운 음식을 좋아해`를 입력 → 즉시 저장됨
   (AI 호출 없음).
2. 🧠 기억 관리 패널을 열어 방금 저장된 기억을 확인, 수정, 삭제해본다.
3. "기억 내보내기"로 JSON을 받고, "가져오기"로 다시 넣어서 유지되는지 확인.
4. 브라우저 콘솔에서 `HolmDiagnostics.run()`을 실행하면 Local AI 항목만
   실패하고 나머지(IndexedDB/Knowledge/대화로그/RAG)는 모두 통과하는 걸 표로
   확인할 수 있다.

### 문제가 계속될 경우 확인해야 할 로그
- Safari 콘솔(Mac + Web Inspector, 또는 iOS 설정 → Safari → 고급 → 웹 검사기)에서
  `[HolmLocalAI] 모델 로딩 실패` 로그를 찾는다 — `code`, `name`, `message`,
  `stack`, `env`(Browser/WebGPU/WASM 등)가 함께 찍힌다.
- ⚙ 설정 패널의 "환경 검사" 텍스트에서 WASM이 "사용 불가"로 나오면 그 기기/OS
  버전 자체의 문제일 가능성이 높다 (매우 드묾).
- `model_download_failed`가 계속 뜨면 네트워크(특히 셀룰러 데이터 절약 모드,
  콘텐츠 차단 확장 프로그램)를 의심해본다.
- `out_of_memory`가 뜨면 다른 탭을 모두 닫고 0.5B 모델로 다시 시도한다.



## 4. Memory 시스템 작동 방식

모든 기억은 `{id, type, content, importance, confidence, source, createdAt,
updatedAt, lastUsedAt, tags}` 구조로 IndexedDB(`memories` 스토어)에 저장됩니다.

- **타입**: user_preference / user_fact / project_fact / instruction /
  important_event / learned_knowledge / conversation_summary
- **중복 방지**: 새 기억이 들어오면 같은 타입의 기존 기억들과 Jaccard 유사도를
  계산해서 0.55 이상이면 새로 만들지 않고 기존 걸 업데이트합니다.
- **신뢰도**: 사용자가 "기억해:"로 직접 말한 내용은 confidence 0.95, AI가
  대화에서 추론한 내용은 0.55로 낮게 저장해서 "AI 추측"과 "사용자가 확정한 사실"을
  구분합니다.
- **채팅 명령**: `기억해: ...` / `기억 목록` / `기억 전체 삭제`
- **UI**: 🧠 아이콘 → 기억 관리 패널에서 타입별로 묶어서 보고, 내용 수정,
  중요도 슬라이더 조절, 삭제, 검색, 전체 초기화가 가능합니다.

## 5. Reflection Engine 작동 방식 (설계상 중요한 부분)

**비용을 두 배로 만들지 않기 위해, 기억 추출을 별도의 AI 호출로 만들지 않았습니다.**
대신 Learning Mode가 켜져 있으면, AI에게 보내는 시스템 프롬프트 끝에
"답변 뒤에 `<memory>[...]</memory>` 태그로 저장할 만한 정보를 JSON으로
붙여라"라는 지시를 함께 보냅니다. AI 응답 하나에서:

1. 사용자에게 보여줄 답변
2. `<memory>` 태그 안의 JSON 기억 후보

를 동시에 뽑아내고, 태그는 화면에 보이지 않게 제거합니다.

- AI가 태그를 안 붙이거나 JSON이 깨지면, 간단한 규칙 기반 백업(선호/지시/자기소개
  패턴 매칭)이 대신 동작합니다. ("오늘 날씨 어때?", "안녕", "ㅋㅋ" 같은 사소한
  대화는 애초에 걸러집니다.)
- 저장 정책: 기존 기억과 비슷하면 조용히 병합 → 새 정보 + 중요도 낮음(<0.75)은
  바로 저장 → 새 정보 + 중요도 높음(≥0.75)은 **Auto Save Memory**가 꺼져 있으면
  "이 내용을 기억할까요?" 승인 토스트를 띄우고, 켜져 있으면 바로 저장합니다.
- **한계**: 내장 소형 모델(0.5B~1.5B)은 이 태그 형식을 완벽히 따르지 못할 때가
  있습니다. 그럴 때는 규칙 기반 백업이 최소한의 기억은 잡아주지만, Claude 같은
  대형 모델을 쓸 때보다 추출 품질이 떨어질 수 있습니다.

## 6. Knowledge DB 작동 방식

Memory와 별도로 `{id, title, content, category, source, confidence, tags}`
구조로 IndexedDB(`knowledge` 스토어)에 저장됩니다. 지금 버전에서는 자동으로
채워지는 파이프라인은 없고(향후 확장 지점), 저장된 것이 있으면 Context
Retrieval이 검색에 포함시킵니다. 기억 관리 패널에서 "지식 내보내기"로 확인/백업할
수 있습니다.

## 7. Context Retrieval 작동 방식

사용자가 질문할 때마다 모든 기억을 보내지 않고, `retrieval.js`가 다음을 검색합니다.

```
사용자 질문
 ├─ Memory 검색 (상위 4개, 키워드 겹침 점수)
 ├─ Knowledge 검색 (상위 3개)
 └─ RAG 문서 검색 (상위 2개, 기존 rag.js 재사용)
        ↓
   관련 있는 것만 프롬프트에 삽입 → AI 호출
```
검색에 사용된 기억은 `lastUsedAt`이 갱신되어 "최근에 참고된 기억"을 추적할 수
있습니다. (실제 임베딩 기반 검색이 아니라 키워드 겹침 근사치입니다.)

---

## 8. 데이터 저장 위치

| 데이터 | 저장 위치 | 이유 |
|---|---|---|
| Memory | IndexedDB (`holm_db_v3` → `memories`) | 계속 커질 수 있음 |
| Knowledge | IndexedDB → `knowledge` | 계속 커질 수 있음 |
| 대화 로그(메타데이터 포함) | IndexedDB → `conversations` | 학습 데이터 준비용, 자동 압축 |
| 화면에 보이는 최근 대화 | localStorage (기존 `storage.js`, 변경 없음) | 가볍고 빠른 표시용 |
| 설정(Settings) | localStorage | 작은 값 |
| RAG 업로드 문서 | localStorage (기존 `rag.js`, 변경 없음) | v2 구조 유지 |

## 9. 실행 방법

위 "1. 빠른 실행 방법" 참고. 추가로:
- ⚙ 설정에서 Budget Mode(무료만 사용/유료 허용), Learning Mode(ON/OFF),
  Auto Save Memory(ON/OFF), AI 연결 방식(내장/외부)을 조절할 수 있습니다.
- 🧠 기억 관리에서 저장된 기억을 보고 수정/삭제/검색하고, JSON으로
  내보내거나(holm-memory.json / holm-knowledge.json), 다시 가져올 수 있습니다.

## 10. 테스트 방법

1. Learning Mode를 켠 채로 "나는 매운 음식을 좋아해" 같은 문장을 보내본다.
2. 잠시 후 🧠 아이콘을 눌러 기억 관리 패널에 `[사용자 선호]` 그룹으로
   저장됐는지 확인한다. (중요도가 낮으면 자동 저장되고, 높으면 승인 토스트가 뜬다.)
3. 새 대화에서 "나 뭐 좋아한다고 했지?" 같은 질문을 하면, Context Retrieval이
   그 기억을 찾아서 AI 답변에 반영되는지 확인한다.
4. 기억 관리 패널에서 내용을 직접 수정하거나 삭제해보고 잘 반영되는지 확인한다.
5. "기억 내보내기"로 holm-memory.json을 받고, "가져오기"로 다시 넣어서
   개수가 유지되는지 확인한다.
6. ⚙ 설정에서 Budget Mode를 "무료만 사용"으로 둔 채 외부 API 키를 넣어보고,
   실제로는 내장 AI만 응답하는지 확인한다 (비용 보호 확인).

## 11. 향후 LoRA 학습을 위해 준비되는 데이터

`public/js/conversation-log.js`가 모든 대화 턴을
`{timestamp, userMessage, holmResponse, relatedMemoryIds, relatedKnowledgeIds}`
형태로 IndexedDB에 쌓습니다. 기억 관리 패널의 "학습 데이터(jsonl)" 버튼을 누르면
`holm-training.jsonl`로 내려받을 수 있고, 각 줄은:

```json
{"messages":[{"role":"user","content":"..."},{"role":"assistant","content":"..."}]}
```

형식입니다. 이번 버전에서는 이 데이터로 실제 모델을 재학습시키지 않습니다.
나중에 데이터가 충분히 쌓이면, 이 JSONL을 Colab 등에서 Qwen2.5에 LoRA로
학습시켜 `public/js/local-ai.js`가 불러오는 모델을 교체하는 식으로 확장할 수
있습니다.

## 12. 기존 v2 기능 중 변경된 부분

- "기억해:" 명령이 이제 `HolmMemory`(localStorage)가 아니라 `HolmMemoryDB`
  (IndexedDB)로 저장됩니다. 저장 형식이 `{type, importance, confidence, ...}`로
  풍부해졌습니다.
- AI에게 보내는 프롬프트에 관련 Memory/Knowledge가 자동으로 삽입됩니다
  (이전에는 RAG 문서만 삽입됐습니다).
- `model-adapter.js`가 단일 어댑터 선택 방식에서, 실패 시 자동으로 다음
  어댑터로 넘어가는 체인 방식으로 바뀌었습니다.
- Budget Mode가 추가되어, 실수로 유료 API가 호출되는 것을 원천 차단할 수
  있습니다.
- 그 외 Core 애니메이션, 상태 시스템, 채팅 UI, 계산기/시간/날짜/검색/Planner/
  Vision/음성/RAG 문서 업로드는 v2와 동일하게 동작합니다.

---

## 13. 우선순위 요약 (이번 버전에서 실제로 구현된 것)

1. ✅ 기존 Holm 기능 유지 (Core 애니메이션, 채팅, 음성, 계산기, 검색, Planner, RAG)
2. ✅ Memory (타입/중요도/신뢰도/중복 방지/UI)
3. ✅ Knowledge DB
4. ✅ Reflection Engine (AI 응답에 통합된 방식, 비용 추가 없음)
5. ✅ Context Retrieval
6. ✅ JSON Export/Import + 학습용 JSONL 내보내기
7. ✅ 무료 우선 구조 (Budget Mode, Local AI 기본값)
8. ✅ HUD 연동 (기억 저장 토스트, 모듈 상태에 개수 표시, 상태 애니메이션 연동)
9. ✅ 향후 LoRA 준비 (대화 로그 → JSONL, 실제 재학습은 하지 않음)
