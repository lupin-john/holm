# brain/

Brain 모듈의 실제 코드는 여기가 아니라 아래 경로에 있습니다.

- `public/js/brain.js` — 두뇌 (입력 라우팅: 메모리/Planner/Tool/RAG/AI)
- `public/js/model-adapter.js` — AI 어댑터 (내장 AI ↔ 외부 API 키 연결 스위치)
- `public/js/local-ai.js` — 브라우저에 내장된 오픈소스 소형 모델(Qwen2.5) 실행
- `public/js/prompt.js` — 프롬프트 빌더

**기본 동작:** 외부 서버에 의존하지 않고, transformers.js로 받아온 오픈소스 모델을
이 기기 안에서 직접 실행합니다. 외부 API 키를 연결하는 것은 선택 사항입니다.
