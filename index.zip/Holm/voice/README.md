# voice/

v1의 실제 구현은 `public/js/voice-input.js` (Web Speech API 음성 인식)와
`public/js/voice-output.js` (SpeechSynthesis 음성 출력)에 있습니다.

**v10 계획:** 더 자연스러운 TTS(예: 실제 AI 음성 API)로 교체하고,
음성 명령으로 Tool을 직접 실행하는 기능을 추가할 예정입니다.
